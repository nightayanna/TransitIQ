# 🇯🇲 TransIQ — Jamaica's AI-Powered Transport Intelligence App

> **Intellibus Hackathon 2026 · March 14–15 · National Arena, Kingston**  
> Team: Jodel · Ayanna · Abby · Brit · Richard

---

## What is TransIQ?

Jamaica's first AI-powered public transport app. Three ML-powered journey plans — Fastest, Cheapest, Balanced — covering Route Taxis, JUTC Buses, Knutsford Express, JUTA, and Uber. Live Kafka traffic updates, Snowflake impact analytics, and a full safety suite with SOS.

---

## Project Structure

```
TransIQ_Mobile/
├── app/                         # Expo Router screens
│   ├── auth/                    # welcome · register · verify · login
│   ├── tabs/                    # Home · Plan · Map · Safety · Account
│   ├── journey/[id].tsx         # Journey detail modal
│   ├── safety/sos.tsx           # Full-screen SOS (Richard)
│   └── admin/                   # Admin panel (ML status · scraper)
├── src/
│   ├── types/ml.ts              # ML model contracts (6 models)
│   ├── utils/api.ts             # Axios client → Spring Boot :8080
│   ├── utils/theme.ts           # TransIQ dark design system
│   ├── store/authStore.ts       # Zustand + SecureStore
│   └── components/
│       └── PlanResultCard.tsx   # 3-plan ML result cards
├── backend/
│   ├── MLGatewayController.java # POST /api/predict
│   ├── MLGatewayService.java    # Lambda invocation + mock mode
│   ├── TransIQKafkaConsumer.java# Kafka topics consumer
│   └── application.yml          # All env vars incl. Lambda ARNs
└── scraper/
    ├── main.py                  # 15-min APScheduler + Kafka publish
    └── scrapers/
        ├── ta_routes_scraper.py # ta.org.jm/available-routes
        ├── ta_fares_scraper.py  # ta.org.jm/routes-and-fares
        └── jutc_scraper.py      # jutc.com.jm
```

---

## Quick Start

### 1. Start infrastructure (Postgres, Kafka, Redis)
```bash
docker compose up -d
```

### 2. Start Spring Boot backend
```bash
cd backend
./mvnw spring-boot:run
# API runs on :8080
# OTPs print to console when TWILIO_* vars are blank
```

### 3. Start Python scraper
```bash
cd scraper
pip install -r requirements.txt
python main.py
# Scrapes immediately, then every 15 minutes
# Publishes route-updates to Kafka on each run
```

### 4. Start React Native app
```bash
npm install
npm start
# i → iOS simulator
# a → Android emulator
# Scan QR with Expo Go for physical device
```

**Physical device:** set `EXPO_PUBLIC_API_URL=http://YOUR_LOCAL_IP:8080` in `.env`

---

## ML Integration

### During development (pre-hackathon)
`EXPO_PUBLIC_ML_MOCK=true` in `.env` → all API calls include `X-Mock: true` header → Spring Boot returns synthetic predictions without calling Lambda.

### On hackathon day (Ayanna deploys Lambda)
1. Ayanna deploys all 6 Lambda functions to AWS
2. Update `.env` (or AWS environment): set all `ML_LAMBDA_*_ARN` vars to actual ARNs
3. Set `EXPO_PUBLIC_ML_MOCK=false`
4. Restart Spring Boot backend
5. **No frontend code changes required**

### 6 ML Models

| Model | Lambda Function | Input | Output |
|-------|----------------|-------|--------|
| 1 — ETA Prediction | `eta-prediction-fn` | origin, dest, depart_time, traffic_level | `{ etaMinutes, confidence }` |
| 2 — Fare Prediction | `fare-prediction-fn` | origin, dest, route_ids, budget_jmd | `{ fareJmd, confidence }` |
| 3 — Traffic Congestion | `traffic-congestion-fn` | route_ids, traffic_level, weather_code | `{ congestionScore, label }` |
| 4 — Best Departure Time | `departure-time-fn` | origin, dest, depart_time, day_of_week | `{ bestDepart, windowMinutes }` |
| 5 — Route Reliability | `reliability-fn` | route_ids, day_of_week, time_of_day | `{ reliabilityScore, grade }` |
| 6 — Safety Score | `safety-score-fn` | route_ids, time_of_day, origin, dest | `{ safetyScore, riskLevel }` |

Schema frozen: **March 12**. No changes after this date.

---

## Kafka Topics

| Topic | Publisher | Consumer |
|-------|-----------|----------|
| `ml-traffic-updates` | traffic-congestion-fn Lambda | Spring Boot → WebSocket → React Native ETA update |
| `ml-safety-alerts` | safety-score-fn Lambda | Spring Boot → Push notification → SOS prompt |
| `route-updates` | Python scraper (15-min) | Spring Boot → invalidate Redis route cache |
| `traffic-events` | Google Maps API poller | Spring Boot → enriches ML predict request |
| `trip-status` | React Native app | Spring Boot → Snowflake analytics |

---

## Demo Script (5 minutes)

| Time | Action |
|------|--------|
| 0:30 | "Every day millions of Jamaicans have no idea how to get from A to B affordably. There is no app for this." |
| 1:30 | Live demo: Spanish Town → Downtown Kingston, 7:30am Monday, JMD 500 budget. Show 3 ML-powered plans appear. |
| 2:30 | **WOW MOMENT**: Trigger Kafka traffic event on Washington Blvd. ML Model 3 fires → Model 1 recalculates ETA live on screen. |
| 3:00 | Show Google Maps with colour-coded congestion segments (Model 3) and SOS button (Model 6 safety score). |
| 3:30 | Show Snowflake impact dashboard: trips planned, avg time saved, avg money saved. |
| 4:00 | Business case: $4B tourism market · Ministry of Transport · scales across every Caribbean island. |
| 4:30 | SPAIN checklist: Stability · Performance · Availability · Integrity · Novelty. |
| 5:00 | "TransIQ is live, deployed, and ready. Jamaica's transport network finally has its backbone." |

---

## Team & Responsibilities

| Person | Role | Key Deliverable |
|--------|------|----------------|
| Jodel | Scraper & Data | ta.org.jm + JUTC scrapers, PostgreSQL schema, Kafka topics |
| Ayanna | ML Engineer | 6 Lambda functions, Flask wrapper, schema locked March 12 |
| Abby | Mobile Frontend | Home, Plan (Route Results), Map screens |
| Brit | Mobile Frontend | Travel Detail, Account, Services screens |
| Richard | Safety & Backend | SOS, off-route detection, Spring Boot API, Kafka consumer |
