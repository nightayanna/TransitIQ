import React from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Alert, ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useRouter } from 'expo-router';
import { adminApi } from '../../src/utils/api';
import { useAuthStore } from '../../src/store/authStore';
import { COLORS } from '../../src/utils/theme';
import Toast from 'react-native-toast-message';

const ML_MODELS = [
  { key: 'eta',         label: 'ETA Prediction',        icon: 'time-outline',         model: 'Model 1' },
  { key: 'fare',        label: 'Fare Prediction',        icon: 'cash-outline',         model: 'Model 2' },
  { key: 'traffic',     label: 'Traffic Congestion',     icon: 'car-outline',          model: 'Model 3' },
  { key: 'departure',   label: 'Best Departure Time',    icon: 'alarm-outline',        model: 'Model 4' },
  { key: 'reliability', label: 'Route Reliability',      icon: 'star-outline',         model: 'Model 5' },
  { key: 'safety',      label: 'Safety Score',           icon: 'shield-checkmark-outline', model: 'Model 6' },
];

export default function AdminScreen() {
  const router = useRouter();
  const { isAdmin } = useAuthStore();
  const qc = useQueryClient();

  if (!isAdmin()) { router.replace('/tabs'); return null; }

  const { data: dashData, isLoading } = useQuery({
    queryKey: ['admin-dashboard'],
    queryFn:  () => adminApi.dashboard().then(r => r.data),
    staleTime: 1000 * 60,
  });

  const { data: mlStatusData } = useQuery({
    queryKey: ['ml-status'],
    queryFn:  () => adminApi.mlStatus().then(r => r.data),
    staleTime: 1000 * 30,
    refetchInterval: 30000,
  });

  const scrapeMutation = useMutation({
    mutationFn: (source?: string) => adminApi.triggerScrape(source),
    onSuccess: () => {
      Toast.show({ type: 'success', text1: 'Scrape triggered!' });
      qc.invalidateQueries({ queryKey: ['admin-dashboard'] });
    },
    onError: () => Toast.show({ type: 'error', text1: 'Scrape failed' }),
  });

  const triggerScrape = (source?: string) => {
    Alert.alert('Trigger Scrape', `Run ${source || 'full'} data scrape now?`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Run Now', onPress: () => scrapeMutation.mutate(source) },
    ]);
  };

  const stats = dashData?.stats || {};

  return (
    <View style={styles.container}>
      <SafeAreaView edges={['top']} style={styles.headerWrap}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
            <Ionicons name="arrow-back" size={20} color="#fff" />
          </TouchableOpacity>
          <MaterialCommunityIcons name="shield-crown" size={20} color={COLORS.gold} />
          <Text style={styles.headerTitle}>Admin Panel</Text>
        </View>
      </SafeAreaView>

      <ScrollView showsVerticalScrollIndicator={false}>
        {isLoading ? (
          <View style={styles.loading}>
            <ActivityIndicator size="large" color={COLORS.teal} />
          </View>
        ) : (
          <>
            {/* System stats */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>System Overview</Text>
              <View style={styles.statsGrid}>
                {[
                  { label: 'Users',    value: stats.users    || 0, icon: 'people',    color: COLORS.teal    },
                  { label: 'Routes',   value: stats.routes   || 0, icon: 'navigate',  color: COLORS.express },
                  { label: 'Trips',    value: stats.trips    || 0, icon: 'time',      color: COLORS.safe    },
                  { label: 'Fares',    value: stats.fares    || 0, icon: 'cash',      color: COLORS.gold    },
                  { label: 'Stops',    value: stats.stops    || 0, icon: 'location',  color: COLORS.taxi    },
                  { label: 'Feedback', value: stats.feedback || 0, icon: 'chatbubble',color: COLORS.juta    },
                ].map((s, i) => (
                  <View key={i} style={styles.statCard}>
                    <View style={[styles.statIcon, { backgroundColor: `${s.color}20` }]}>
                      <Ionicons name={s.icon as any} size={18} color={s.color} />
                    </View>
                    <Text style={styles.statValue}>{s.value.toLocaleString()}</Text>
                    <Text style={styles.statLabel}>{s.label}</Text>
                  </View>
                ))}
              </View>
            </View>

            {/* ML Lambda status */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>ML Model Status</Text>
              <View style={styles.mlCard}>
                <View style={styles.mlHeader}>
                  <MaterialCommunityIcons name="brain" size={18} color={COLORS.teal} />
                  <Text style={styles.mlHeaderText}>Lambda Functions</Text>
                  <View style={[styles.mlModeBadge, { backgroundColor: mlStatusData?.allLive ? `${COLORS.teal}20` : `${COLORS.gold}20` }]}>
                    <Text style={[styles.mlModeText, { color: mlStatusData?.allLive ? COLORS.teal : COLORS.gold }]}>
                      {mlStatusData?.allLive ? 'LIVE' : 'MOCK'}
                    </Text>
                  </View>
                </View>
                {ML_MODELS.map((m, i) => {
                  const status = mlStatusData?.models?.[m.key];
                  const isLive = status?.live;
                  return (
                    <View key={i} style={styles.mlRow}>
                      <Ionicons name={m.icon as any} size={16} color={isLive ? COLORS.teal : COLORS.muted} />
                      <View style={{ flex: 1 }}>
                        <Text style={styles.mlModelLabel}>{m.label}</Text>
                        <Text style={styles.mlModelSub}>{m.model} · {isLive ? `MAE: ${status?.mae || '—'}` : 'Mock mode'}</Text>
                      </View>
                      <View style={[styles.mlStatusDot, { backgroundColor: isLive ? COLORS.teal : COLORS.gold }]} />
                    </View>
                  );
                })}
              </View>
            </View>

            {/* Scraper controls */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Data Scraper</Text>
              <View style={styles.scrapeCard}>
                <Text style={styles.scrapeDesc}>
                  Auto-scrapes run every 15 minutes. Trigger manually below.
                </Text>
                <View style={styles.scrapeButtons}>
                  {[
                    { key: 'ta',   label: 'TA Routes',  color: COLORS.taxi    },
                    { key: 'jutc', label: 'JUTC',        color: COLORS.bus     },
                    { key: 'uber', label: 'Uber Fares',  color: COLORS.uber    },
                  ].map(s => (
                    <TouchableOpacity
                      key={s.key}
                      style={[styles.scrapeBtn, { borderColor: s.color }]}
                      onPress={() => triggerScrape(s.key)}
                      disabled={scrapeMutation.isPending}
                    >
                      <Text style={[styles.scrapeBtnText, { color: s.color }]}>{s.label}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
                <TouchableOpacity
                  style={[styles.fullScrapeBtn, scrapeMutation.isPending && { opacity: 0.5 }]}
                  onPress={() => triggerScrape()}
                  disabled={scrapeMutation.isPending}
                  activeOpacity={0.85}
                >
                  {scrapeMutation.isPending
                    ? <ActivityIndicator color="#fff" size="small" />
                    : <><Ionicons name="refresh" size={18} color="#fff" /><Text style={styles.fullScrapeBtnText}>Run Full Scrape</Text></>
                  }
                </TouchableOpacity>
              </View>
            </View>

            {/* Snowflake analytics summary */}
            <View style={[styles.section, { marginBottom: 32 }]}>
              <Text style={styles.sectionTitle}>Snowflake Analytics</Text>
              <View style={styles.snowflakeCard}>
                <MaterialCommunityIcons name="snowflake" size={20} color="#60A5FA" />
                <View style={{ flex: 1 }}>
                  <Text style={styles.snowflakeTitle}>Data Warehouse Connected</Text>
                  <Text style={styles.snowflakeSub}>
                    {stats.totalTrips?.toLocaleString() || '—'} total trips · {stats.avgTimeSaved || '—'}m avg time saved
                  </Text>
                </View>
              </View>
            </View>
          </>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container:         { flex: 1, backgroundColor: COLORS.background },
  headerWrap:        { backgroundColor: COLORS.navy },
  header:            { flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 16, paddingBottom: 16, paddingTop: 10 },
  backBtn:           { width: 34, height: 34, borderRadius: 10, backgroundColor: `${COLORS.white}10`, justifyContent: 'center', alignItems: 'center' },
  headerTitle:       { flex: 1, fontSize: 20, fontWeight: '800', color: COLORS.text },
  loading:           { flex: 1, alignItems: 'center', paddingTop: 60 },
  section:           { padding: 16, paddingBottom: 0 },
  sectionTitle:      { fontSize: 17, fontWeight: '700', color: COLORS.text, marginBottom: 12 },
  statsGrid:         { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  statCard:          { width: '30%', flexGrow: 1, backgroundColor: COLORS.surface, borderRadius: 14, padding: 12, alignItems: 'center', gap: 4, borderWidth: 1, borderColor: COLORS.border },
  statIcon:          { width: 36, height: 36, borderRadius: 10, justifyContent: 'center', alignItems: 'center', marginBottom: 4 },
  statValue:         { fontSize: 18, fontWeight: '800', color: COLORS.text },
  statLabel:         { fontSize: 10, color: COLORS.muted },
  mlCard:            { backgroundColor: COLORS.surface, borderRadius: 16, padding: 16, borderWidth: 1, borderColor: COLORS.border, marginBottom: 16 },
  mlHeader:          { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12, paddingBottom: 12, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  mlHeaderText:      { flex: 1, fontSize: 15, fontWeight: '700', color: COLORS.text },
  mlModeBadge:       { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20 },
  mlModeText:        { fontSize: 12, fontWeight: '800', letterSpacing: 1 },
  mlRow:             { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  mlModelLabel:      { fontSize: 13, fontWeight: '600', color: COLORS.text },
  mlModelSub:        { fontSize: 11, color: COLORS.muted, marginTop: 1 },
  mlStatusDot:       { width: 8, height: 8, borderRadius: 4 },
  scrapeCard:        { backgroundColor: COLORS.surface, borderRadius: 16, padding: 16, borderWidth: 1, borderColor: COLORS.border, marginBottom: 16 },
  scrapeDesc:        { fontSize: 13, color: COLORS.textSec, marginBottom: 14 },
  scrapeButtons:     { flexDirection: 'row', gap: 8, marginBottom: 12 },
  scrapeBtn:         { flex: 1, paddingVertical: 8, borderRadius: 10, borderWidth: 1.5, alignItems: 'center' },
  scrapeBtnText:     { fontSize: 12, fontWeight: '700' },
  fullScrapeBtn:     { backgroundColor: COLORS.navy, paddingVertical: 13, borderRadius: 12, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 8, borderWidth: 1, borderColor: COLORS.border },
  fullScrapeBtnText: { fontSize: 14, fontWeight: '700', color: '#fff' },
  snowflakeCard:     { backgroundColor: COLORS.surface, borderRadius: 14, padding: 16, flexDirection: 'row', alignItems: 'center', gap: 12, borderWidth: 1, borderColor: COLORS.border },
  snowflakeTitle:    { fontSize: 14, fontWeight: '700', color: COLORS.text },
  snowflakeSub:      { fontSize: 12, color: COLORS.textSec, marginTop: 2 },
});
