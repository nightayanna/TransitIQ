import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TextInput, TouchableOpacity,
  KeyboardAvoidingView, Platform,
} from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import Toast from 'react-native-toast-message';
import { useAuthStore } from '../../src/store/authStore';
import { authApi } from '../../src/utils/api';
import { COLORS } from '../../src/utils/theme';

export default function LoginScreen() {
  const router = useRouter();
  const { setPending } = useAuthStore();
  const [phone, setPhone]     = useState('');
  const [loading, setLoading] = useState(false);

  const formatPhone = (raw: string) => {
    const d = raw.replace(/\D/g, '');
    if (d.startsWith('1876') && d.length === 11) return `+${d}`;
    if (d.startsWith('876')  && d.length === 10)  return `+1${d}`;
    if (d.length === 7)                            return `+1876${d}`;
    return raw;
  };

  const handleLogin = async () => {
    const formatted = formatPhone(phone);
    if (!formatted.startsWith('+')) {
      Toast.show({ type: 'error', text1: 'Enter a valid Jamaican number' }); return;
    }
    try {
      setLoading(true);
      await authApi.register(formatted, '');
      setPending(formatted);
      router.push('/auth/verify');
    } catch (err: any) {
      Toast.show({ type: 'error', text1: err.response?.data?.message || 'Login failed' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#0D9488', COLORS.navy, '#030D1A']} style={StyleSheet.absoluteFill} start={{ x: 0, y: 0 }} end={{ x: 0.3, y: 1 }} />
      <SafeAreaView style={styles.safe}>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
          <View style={styles.inner}>
            <TouchableOpacity style={styles.back} onPress={() => router.back()}>
              <Ionicons name="arrow-back" size={22} color="#fff" />
            </TouchableOpacity>

            <View style={styles.header}>
              <MaterialCommunityIcons name="brain" size={44} color={COLORS.teal} style={{ marginBottom: 14 }} />
              <Text style={styles.title}>Welcome Back</Text>
              <Text style={styles.sub}>Enter your phone to receive a sign-in code</Text>
            </View>

            <View style={styles.card}>
              <Text style={styles.label}>Phone Number</Text>
              <View style={styles.inputRow}>
                <View style={styles.prefix}>
                  <Text style={styles.prefixText}>🇯🇲 +1876</Text>
                </View>
                <TextInput
                  style={styles.input}
                  placeholder="XXX-XXXX"
                  placeholderTextColor={COLORS.muted}
                  value={phone}
                  onChangeText={setPhone}
                  keyboardType="phone-pad"
                  maxLength={16}
                  autoFocus
                  returnKeyType="done"
                  onSubmitEditing={handleLogin}
                />
              </View>

              <TouchableOpacity
                style={[styles.btn, loading && styles.btnDisabled]}
                onPress={handleLogin}
                disabled={loading}
                activeOpacity={0.85}
              >
                <LinearGradient colors={[COLORS.teal, '#0B7A6E']} style={styles.btnGradient} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}>
                  <Text style={styles.btnText}>{loading ? 'Sending...' : 'Send Code'}</Text>
                  {!loading && <Ionicons name="arrow-forward" size={18} color="#fff" />}
                </LinearGradient>
              </TouchableOpacity>
            </View>

            <TouchableOpacity style={styles.registerLink} onPress={() => router.push('/auth/register')}>
              <Text style={styles.registerText}>
                New to TransIQ? <Text style={{ color: COLORS.teal, fontWeight: '700' }}>Create account</Text>
              </Text>
            </TouchableOpacity>
          </View>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container:    { flex: 1 },
  safe:         { flex: 1 },
  inner:        { flex: 1, padding: 28, justifyContent: 'center' },
  back:         { position: 'absolute', top: 16, left: 28, zIndex: 10, width: 40, height: 40, justifyContent: 'center' },
  header:       { alignItems: 'center', marginBottom: 32 },
  title:        { fontSize: 30, fontWeight: '800', color: '#fff' },
  sub:          { fontSize: 14, color: COLORS.textSec, marginTop: 8, textAlign: 'center' },
  card:         { backgroundColor: COLORS.surface, borderRadius: 24, padding: 24, borderWidth: 1, borderColor: COLORS.border, marginBottom: 24 },
  label:        { fontSize: 12, fontWeight: '600', color: COLORS.textSec, marginBottom: 8, textTransform: 'uppercase', letterSpacing: 0.5 },
  inputRow:     { flexDirection: 'row', alignItems: 'center', borderWidth: 1.5, borderColor: COLORS.border, borderRadius: 12, backgroundColor: COLORS.background, overflow: 'hidden', marginBottom: 18 },
  prefix:       { backgroundColor: COLORS.navyLight, paddingHorizontal: 12, paddingVertical: 14, borderRightWidth: 1, borderRightColor: COLORS.border },
  prefixText:   { fontSize: 14, fontWeight: '600', color: COLORS.textSec },
  input:        { flex: 1, paddingVertical: 14, paddingHorizontal: 12, fontSize: 18, color: COLORS.text, fontWeight: '600' },
  btn:          { borderRadius: 14, overflow: 'hidden' },
  btnDisabled:  { opacity: 0.6 },
  btnGradient:  { paddingVertical: 16, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 8 },
  btnText:      { fontSize: 16, fontWeight: '700', color: '#fff' },
  registerLink: { alignItems: 'center' },
  registerText: { fontSize: 14, color: COLORS.textSec },
});
