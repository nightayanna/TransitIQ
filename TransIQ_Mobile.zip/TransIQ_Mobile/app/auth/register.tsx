import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TextInput, TouchableOpacity,
  KeyboardAvoidingView, Platform, ScrollView,
} from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import Toast from 'react-native-toast-message';
import { useAuthStore } from '../../src/store/authStore';
import { authApi } from '../../src/utils/api';
import { COLORS } from '../../src/utils/theme';

export default function RegisterScreen() {
  const router = useRouter();
  const { setPending } = useAuthStore();
  const [name, setName]       = useState('');
  const [phone, setPhone]     = useState('');
  const [loading, setLoading] = useState(false);

  const formatPhone = (raw: string) => {
    const digits = raw.replace(/\D/g, '');
    if (digits.startsWith('1876') && digits.length === 11) return `+${digits}`;
    if (digits.startsWith('876')  && digits.length === 10)  return `+1${digits}`;
    if (digits.length === 7)                                return `+1876${digits}`;
    return raw;
  };

  const handleRegister = async () => {
    if (!name.trim() || name.trim().length < 2) {
      Toast.show({ type: 'error', text1: 'Enter your full name' }); return;
    }
    const formatted = formatPhone(phone);
    if (!formatted.startsWith('+')) {
      Toast.show({ type: 'error', text1: 'Enter a valid Jamaican phone number' }); return;
    }
    try {
      setLoading(true);
      await authApi.register(formatted, name.trim());
      setPending(formatted);
      router.push('/auth/verify');
    } catch (err: any) {
      Toast.show({ type: 'error', text1: err.response?.data?.message || 'Registration failed' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <LinearGradient colors={[COLORS.navy, '#061428', '#030D1A']} style={StyleSheet.absoluteFill} />
      <SafeAreaView style={styles.safe}>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
          <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
            <TouchableOpacity style={styles.back} onPress={() => router.back()}>
              <Ionicons name="arrow-back" size={22} color="#fff" />
            </TouchableOpacity>

            <View style={styles.header}>
              <View style={styles.logoRow}>
                <MaterialCommunityIcons name="brain" size={28} color={COLORS.teal} />
                <Text style={styles.appName}>TransIQ</Text>
              </View>
              <Text style={styles.title}>Create Account</Text>
              <Text style={styles.sub}>Join Jamaica's first AI transport app</Text>
            </View>

            <View style={styles.card}>
              <View style={styles.inputGroup}>
                <Text style={styles.label}>Full Name</Text>
                <View style={styles.inputRow}>
                  <Ionicons name="person-outline" size={18} color={COLORS.teal} style={{ marginLeft: 14 }} />
                  <TextInput
                    style={styles.input}
                    placeholder="e.g. Marcus Thompson"
                    placeholderTextColor={COLORS.muted}
                    value={name}
                    onChangeText={setName}
                    autoCapitalize="words"
                    returnKeyType="next"
                  />
                </View>
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>Phone Number</Text>
                <View style={styles.inputRow}>
                  <View style={styles.prefix}>
                    <Text style={styles.prefixText}>🇯🇲 +1876</Text>
                  </View>
                  <TextInput
                    style={[styles.input, { paddingLeft: 8 }]}
                    placeholder="XXX-XXXX"
                    placeholderTextColor={COLORS.muted}
                    value={phone}
                    onChangeText={setPhone}
                    keyboardType="phone-pad"
                    maxLength={16}
                    returnKeyType="done"
                    onSubmitEditing={handleRegister}
                  />
                </View>
                <Text style={styles.hint}>We'll send a verification code via SMS</Text>
              </View>

              <TouchableOpacity
                style={[styles.btn, loading && styles.btnDisabled]}
                onPress={handleRegister}
                disabled={loading}
                activeOpacity={0.85}
              >
                <LinearGradient colors={[COLORS.teal, '#0B7A6E']} style={styles.btnGradient} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}>
                  <Text style={styles.btnText}>{loading ? 'Sending code...' : 'Send Verification Code'}</Text>
                  {!loading && <Ionicons name="send" size={16} color="#fff" />}
                </LinearGradient>
              </TouchableOpacity>
            </View>

            <TouchableOpacity style={styles.loginLink} onPress={() => router.push('/auth/login')}>
              <Text style={styles.loginLinkText}>Already have an account? <Text style={{ color: COLORS.teal, fontWeight: '700' }}>Log in</Text></Text>
            </TouchableOpacity>
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container:   { flex: 1 },
  safe:        { flex: 1 },
  scroll:      { flexGrow: 1, padding: 24, paddingBottom: 40 },
  back:        { width: 40, height: 40, justifyContent: 'center', marginBottom: 24 },
  header:      { marginBottom: 28 },
  logoRow:     { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 16 },
  appName:     { fontSize: 26, fontWeight: '900', color: '#fff' },
  title:       { fontSize: 30, fontWeight: '800', color: '#fff', letterSpacing: -0.5 },
  sub:         { fontSize: 14, color: COLORS.textSec, marginTop: 8 },
  card:        { backgroundColor: COLORS.surface, borderRadius: 24, padding: 24, borderWidth: 1, borderColor: COLORS.border, marginBottom: 24 },
  inputGroup:  { marginBottom: 18 },
  label:       { fontSize: 12, fontWeight: '600', color: COLORS.textSec, marginBottom: 8, textTransform: 'uppercase', letterSpacing: 0.5 },
  inputRow:    { flexDirection: 'row', alignItems: 'center', borderWidth: 1.5, borderColor: COLORS.border, borderRadius: 12, backgroundColor: COLORS.background, overflow: 'hidden' },
  input:       { flex: 1, paddingVertical: 14, paddingHorizontal: 12, fontSize: 16, color: COLORS.text },
  prefix:      { backgroundColor: COLORS.navyLight, paddingHorizontal: 12, paddingVertical: 14, borderRightWidth: 1, borderRightColor: COLORS.border },
  prefixText:  { fontSize: 14, fontWeight: '600', color: COLORS.textSec },
  hint:        { fontSize: 12, color: COLORS.muted, marginTop: 6 },
  btn:         { borderRadius: 14, overflow: 'hidden', marginTop: 8 },
  btnDisabled: { opacity: 0.6 },
  btnGradient: { paddingVertical: 16, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 8 },
  btnText:     { fontSize: 16, fontWeight: '700', color: '#fff' },
  loginLink:   { alignItems: 'center' },
  loginLinkText: { fontSize: 14, color: COLORS.textSec },
});
