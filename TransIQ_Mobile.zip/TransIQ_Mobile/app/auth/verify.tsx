import React, { useState, useRef, useEffect } from 'react';
import {
  View, Text, StyleSheet, TextInput, TouchableOpacity,
  KeyboardAvoidingView, Platform, Animated,
} from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import Toast from 'react-native-toast-message';
import { useAuthStore } from '../../src/store/authStore';
import { authApi } from '../../src/utils/api';
import { COLORS } from '../../src/utils/theme';

export default function VerifyScreen() {
  const router = useRouter();
  const { pendingPhone, setAuth } = useAuthStore();
  const [otp, setOtp]         = useState(['', '', '', '', '', '']);
  const [loading, setLoading] = useState(false);
  const [countdown, setCountdown] = useState(60);
  const [canResend, setCanResend] = useState(false);
  const refs    = useRef<TextInput[]>([]);
  const shake   = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const t = setInterval(() => {
      setCountdown(c => { if (c <= 1) { setCanResend(true); clearInterval(t); return 0; } return c - 1; });
    }, 1000);
    return () => clearInterval(t);
  }, []);

  const doShake = () => Animated.sequence([
    Animated.timing(shake, { toValue: 10,  duration: 50, useNativeDriver: true }),
    Animated.timing(shake, { toValue: -10, duration: 50, useNativeDriver: true }),
    Animated.timing(shake, { toValue: 10,  duration: 50, useNativeDriver: true }),
    Animated.timing(shake, { toValue: 0,   duration: 50, useNativeDriver: true }),
  ]).start();

  const handleChange = (val: string, i: number) => {
    const next = [...otp];
    next[i] = val.slice(-1);
    setOtp(next);
    if (val && i < 5) refs.current[i + 1]?.focus();
    if (next.every(d => d) && !loading) verify(next.join(''));
  };

  const handleKey = (e: any, i: number) => {
    if (e.nativeEvent.key === 'Backspace' && !otp[i] && i > 0) refs.current[i - 1]?.focus();
  };

  const verify = async (code?: string) => {
    const full = code || otp.join('');
    if (full.length !== 6) { Toast.show({ type: 'error', text1: 'Enter the 6-digit code' }); return; }
    try {
      setLoading(true);
      const res = await authApi.verifyOtp(pendingPhone, full);
      await setAuth(res.data.token, res.data.user);
      Toast.show({ type: 'success', text1: `Welcome to TransIQ, ${res.data.user.name.split(' ')[0]}!` });
      router.replace('/tabs');
    } catch (err: any) {
      doShake();
      setOtp(['', '', '', '', '', '']);
      refs.current[0]?.focus();
      Toast.show({ type: 'error', text1: err.response?.data?.message || 'Invalid code' });
    } finally {
      setLoading(false);
    }
  };

  const masked = pendingPhone.replace(/(\+\d{5})\d+(\d{4})/, '$1•••$2');

  return (
    <View style={styles.container}>
      <LinearGradient colors={[COLORS.navy, '#061428', '#030D1A']} style={StyleSheet.absoluteFill} />
      <SafeAreaView style={styles.safe}>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
          <View style={styles.inner}>
            <TouchableOpacity style={styles.back} onPress={() => router.back()}>
              <Ionicons name="arrow-back" size={22} color="#fff" />
            </TouchableOpacity>

            <View style={styles.header}>
              <View style={styles.iconCircle}>
                <Ionicons name="chatbubble-ellipses" size={30} color={COLORS.teal} />
              </View>
              <Text style={styles.title}>Verify Number</Text>
              <Text style={styles.sub}>Enter the 6-digit code sent to</Text>
              <Text style={styles.phone}>{masked}</Text>
            </View>

            <Animated.View style={[styles.otpRow, { transform: [{ translateX: shake }] }]}>
              {otp.map((d, i) => (
                <TextInput
                  key={i}
                  ref={r => { if (r) refs.current[i] = r; }}
                  style={[styles.box, d && styles.boxFilled, loading && styles.boxLoading]}
                  value={d}
                  onChangeText={v => handleChange(v, i)}
                  onKeyPress={e => handleKey(e, i)}
                  keyboardType="number-pad"
                  maxLength={1}
                  selectTextOnFocus
                  editable={!loading}
                />
              ))}
            </Animated.View>

            <Text style={styles.devHint}>Dev mode: check Spring Boot console for OTP</Text>

            <TouchableOpacity
              style={[styles.btn, (loading || otp.some(d => !d)) && styles.btnDisabled]}
              onPress={() => verify()}
              disabled={loading || otp.some(d => !d)}
              activeOpacity={0.85}
            >
              <LinearGradient colors={[COLORS.teal, '#0B7A6E']} style={styles.btnGradient} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}>
                <Text style={styles.btnText}>{loading ? 'Verifying...' : 'Verify & Continue'}</Text>
              </LinearGradient>
            </TouchableOpacity>

            <TouchableOpacity style={styles.resend} onPress={() => {}} disabled={!canResend}>
              <Text style={[styles.resendText, canResend && { color: COLORS.teal }]}>
                {canResend ? 'Resend code' : `Resend in ${countdown}s`}
              </Text>
            </TouchableOpacity>
          </View>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container:   { flex: 1 },
  safe:        { flex: 1 },
  inner:       { flex: 1, padding: 24, justifyContent: 'center' },
  back:        { position: 'absolute', top: 16, left: 24, zIndex: 10, width: 40, height: 40, justifyContent: 'center' },
  header:      { alignItems: 'center', marginBottom: 36 },
  iconCircle:  { width: 72, height: 72, borderRadius: 20, backgroundColor: `${COLORS.teal}20`, borderWidth: 1, borderColor: `${COLORS.teal}30`, justifyContent: 'center', alignItems: 'center', marginBottom: 18 },
  title:       { fontSize: 28, fontWeight: '800', color: '#fff' },
  sub:         { fontSize: 14, color: COLORS.textSec, marginTop: 8 },
  phone:       { fontSize: 16, fontWeight: '700', color: COLORS.teal, marginTop: 4 },
  otpRow:      { flexDirection: 'row', justifyContent: 'center', gap: 10, marginBottom: 12 },
  box:         { width: 48, height: 56, borderRadius: 12, backgroundColor: COLORS.surface, borderWidth: 1.5, borderColor: COLORS.border, textAlign: 'center', fontSize: 24, fontWeight: '700', color: COLORS.text },
  boxFilled:   { borderColor: COLORS.teal, backgroundColor: `${COLORS.teal}15` },
  boxLoading:  { opacity: 0.5 },
  devHint:     { fontSize: 12, color: COLORS.muted, textAlign: 'center', marginBottom: 24 },
  btn:         { borderRadius: 14, overflow: 'hidden', marginBottom: 16 },
  btnDisabled: { opacity: 0.4 },
  btnGradient: { paddingVertical: 16, alignItems: 'center' },
  btnText:     { fontSize: 16, fontWeight: '700', color: '#fff' },
  resend:      { alignItems: 'center' },
  resendText:  { fontSize: 14, color: COLORS.muted, fontWeight: '600' },
});
