import React, { useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity,
  Animated, Dimensions, StatusBar,
} from 'react-native';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { COLORS } from '../../src/utils/theme';

const { width, height } = Dimensions.get('window');

const TRANSPORT_TYPES = [
  { icon: 'bus',        label: 'JUTC Buses',   color: COLORS.bus    },
  { icon: 'taxi',       label: 'Route Taxis',  color: COLORS.taxi   },
  { icon: 'bus-coach',  label: 'Express',      color: COLORS.express},
  { icon: 'leaf',       label: 'JUTA',         color: COLORS.juta   },
  { icon: 'car',        label: 'Uber',         color: COLORS.uber   },
];

export default function WelcomeScreen() {
  const router  = useRouter();
  const fadeIn  = useRef(new Animated.Value(0)).current;
  const slideUp = useRef(new Animated.Value(30)).current;
  const pulse   = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeIn,  { toValue: 1, duration: 900, useNativeDriver: true }),
      Animated.timing(slideUp, { toValue: 0, duration: 800, useNativeDriver: true }),
    ]).start();

    Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1.06, duration: 1800, useNativeDriver: true }),
        Animated.timing(pulse, { toValue: 1,    duration: 1800, useNativeDriver: true }),
      ])
    ).start();
  }, []);

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={COLORS.navy} />
      <LinearGradient
        colors={[COLORS.navy, '#061428', '#030D1A']}
        style={StyleSheet.absoluteFill}
      />

      {/* Grid overlay effect */}
      <View style={styles.gridOverlay} pointerEvents="none" />

      <SafeAreaView style={styles.safe}>
        {/* Logo */}
        <Animated.View style={[styles.logoWrap, { opacity: fadeIn, transform: [{ scale: pulse }] }]}>
          <View style={styles.logoBadge}>
            <MaterialCommunityIcons name="brain" size={36} color={COLORS.teal} />
          </View>
          <Text style={styles.appName}>TransIQ</Text>
          <View style={styles.aiBadge}>
            <View style={styles.aiDot} />
            <Text style={styles.aiLabel}>AI-POWERED</Text>
          </View>
        </Animated.View>

        {/* Transport pills */}
        <Animated.View style={[styles.pillRow, { opacity: fadeIn, transform: [{ translateY: slideUp }] }]}>
          {TRANSPORT_TYPES.map((t, i) => (
            <View key={i} style={[styles.pill, { borderColor: `${t.color}50` }]}>
              <MaterialCommunityIcons name={t.icon as any} size={14} color={t.color} />
              <Text style={[styles.pillText, { color: t.color }]}>{t.label}</Text>
            </View>
          ))}
        </Animated.View>

        {/* Hero */}
        <Animated.View style={[styles.hero, { opacity: fadeIn, transform: [{ translateY: slideUp }] }]}>
          <Text style={styles.heroTitle}>Jamaica's First{'\n'}AI Transport App</Text>
          <Text style={styles.heroSub}>
            3 ML-powered plans — Fastest, Cheapest, Balanced{'\n'}
            Live traffic · Real fares · Safety scores
          </Text>
        </Animated.View>

        {/* CTAs */}
        <Animated.View style={[styles.ctas, { opacity: fadeIn }]}>
          <TouchableOpacity
            style={styles.btnPrimary}
            onPress={() => router.push('/auth/register')}
            activeOpacity={0.85}
          >
            <LinearGradient
              colors={[COLORS.teal, '#0B7A6E']}
              style={styles.btnGradient}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
            >
              <Text style={styles.btnPrimaryText}>Get Started</Text>
              <Ionicons name="arrow-forward" size={18} color="#fff" />
            </LinearGradient>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.btnSecondary}
            onPress={() => router.push('/auth/login')}
            activeOpacity={0.85}
          >
            <Text style={styles.btnSecondaryText}>I already have an account</Text>
          </TouchableOpacity>
        </Animated.View>

        {/* Hackathon badge */}
        <Animated.View style={[styles.hackathonBadge, { opacity: fadeIn }]}>
          <Ionicons name="trophy-outline" size={12} color={COLORS.gold} />
          <Text style={styles.hackathonText}>Intellibus Hackathon 2026 · National Arena, Kingston</Text>
        </Animated.View>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container:       { flex: 1 },
  safe:            { flex: 1, paddingHorizontal: 24, justifyContent: 'space-between', paddingVertical: 28 },
  gridOverlay:     { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, opacity: 0.03,
                     backgroundImage: undefined },

  logoWrap:        { alignItems: 'center', marginTop: 20 },
  logoBadge:       { width: 80, height: 80, borderRadius: 22, backgroundColor: `${COLORS.teal}20`,
                     borderWidth: 1, borderColor: `${COLORS.teal}40`,
                     justifyContent: 'center', alignItems: 'center', marginBottom: 14 },
  appName:         { fontSize: 48, fontWeight: '900', color: '#fff', letterSpacing: -1 },
  aiBadge:         { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 6,
                     backgroundColor: `${COLORS.teal}20`, paddingHorizontal: 12, paddingVertical: 4,
                     borderRadius: 20, borderWidth: 1, borderColor: `${COLORS.teal}30` },
  aiDot:           { width: 6, height: 6, borderRadius: 3, backgroundColor: COLORS.teal },
  aiLabel:         { fontSize: 11, color: COLORS.teal, fontWeight: '700', letterSpacing: 1.5 },

  pillRow:         { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: 8 },
  pill:            { flexDirection: 'row', alignItems: 'center', gap: 5,
                     backgroundColor: COLORS.surface, paddingHorizontal: 10, paddingVertical: 6,
                     borderRadius: 20, borderWidth: 1 },
  pillText:        { fontSize: 11, fontWeight: '700' },

  hero:            { alignItems: 'center' },
  heroTitle:       { fontSize: 34, fontWeight: '800', color: '#fff', textAlign: 'center',
                     lineHeight: 40, letterSpacing: -0.5 },
  heroSub:         { fontSize: 14, color: COLORS.textSec, textAlign: 'center', marginTop: 12, lineHeight: 22 },

  ctas:            { gap: 12 },
  btnPrimary:      { borderRadius: 14, overflow: 'hidden' },
  btnGradient:     { paddingVertical: 16, flexDirection: 'row', justifyContent: 'center',
                     alignItems: 'center', gap: 8 },
  btnPrimaryText:  { fontSize: 17, fontWeight: '700', color: '#fff' },
  btnSecondary:    { backgroundColor: COLORS.surface, paddingVertical: 15, borderRadius: 14,
                     alignItems: 'center', borderWidth: 1, borderColor: COLORS.border },
  btnSecondaryText:{ fontSize: 15, fontWeight: '600', color: COLORS.textSec },

  hackathonBadge:  { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 5 },
  hackathonText:   { fontSize: 11, color: COLORS.muted, textAlign: 'center' },
});
