import React from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  ActivityIndicator, Share,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import Toast from 'react-native-toast-message';
import { routeApi } from '../../src/utils/api';
import { COLORS } from '../../src/utils/theme';
import PlanResultCard from '../../src/components/PlanResultCard';

export default function JourneyDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router  = useRouter();
  const qc      = useQueryClient();

  const { data, isLoading } = useQuery({
    queryKey: ['journey', id],
    queryFn:  () => routeApi.get(id!).then(r => r.data),
    enabled:  !!id,
  });

  const completeMutation = useMutation({
    mutationFn: () => routeApi.complete(id!),
    onSuccess: () => {
      Toast.show({ type: 'success', text1: 'Journey completed ✓' });
      qc.invalidateQueries({ queryKey: ['route-history'] });
    },
  });

  const saveMutation = useMutation({
    mutationFn: () => routeApi.save(id!),
    onSuccess: () => Toast.show({ type: 'success', text1: 'Route saved!' }),
  });

  const handleShare = async () => {
    if (!data) return;
    await Share.share({
      message: `My TransIQ trip: ${data.origin} → ${data.destination}\n${data.etaMinutes} min · JMD ${data.fareJmd}\nPlan: ${data.planType}`,
      title: 'TransIQ Journey',
    });
  };

  if (isLoading) return (
    <View style={styles.loading}>
      <ActivityIndicator size="large" color={COLORS.teal} />
    </View>
  );

  const journey = data;

  return (
    <View style={styles.container}>
      <SafeAreaView edges={['top']} style={styles.headerWrap}>
        <View style={styles.header}>
          <TouchableOpacity style={styles.closeBtn} onPress={() => router.back()}>
            <Ionicons name="close" size={22} color="#fff" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Journey Details</Text>
          <TouchableOpacity style={styles.shareBtn} onPress={handleShare}>
            <Ionicons name="share-outline" size={20} color="#fff" />
          </TouchableOpacity>
        </View>
      </SafeAreaView>

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Route header */}
        <View style={styles.routeCard}>
          <View style={styles.routeRow}>
            <View style={styles.endpoint}>
              <View style={[styles.dot, { backgroundColor: COLORS.teal }]} />
              <Text style={styles.endpointName} numberOfLines={2}>{journey?.origin}</Text>
            </View>
            <View style={styles.arrowWrap}>
              <View style={styles.arrowLine} />
              <Ionicons name="arrow-forward" size={14} color={COLORS.muted} />
            </View>
            <View style={styles.endpoint}>
              <View style={[styles.dot, { backgroundColor: COLORS.gold }]} />
              <Text style={styles.endpointName} numberOfLines={2}>{journey?.destination}</Text>
            </View>
          </View>

          {/* Stats */}
          <View style={styles.statsRow}>
            {[
              { icon: 'time-outline',  value: `${journey?.etaMinutes || '—'} min` },
              { icon: 'cash-outline',  value: `JMD ${journey?.fareJmd || '—'}` },
              { icon: 'git-merge-outline', value: `${journey?.transfers || 0} transfers` },
            ].map((s, i) => (
              <View key={i} style={[styles.stat, i < 2 && styles.statDivider]}>
                <Ionicons name={s.icon as any} size={16} color={COLORS.teal} />
                <Text style={styles.statValue}>{s.value}</Text>
              </View>
            ))}
          </View>

          {/* ML scores summary */}
          {journey?.ml && (
            <View style={styles.mlSummary}>
              <MaterialCommunityIcons name="brain" size={14} color={COLORS.teal} />
              <Text style={styles.mlSummaryText}>
                Safety {journey.ml.safety?.safetyScore}/100 · Grade {journey.ml.reliability?.grade} · {journey.ml.traffic?.label} traffic
              </Text>
              {journey.ml.isMock && <Text style={styles.mockTag}>MOCK</Text>}
            </View>
          )}
        </View>

        {/* Actions */}
        <View style={styles.actions}>
          {journey?.status !== 'completed' && (
            <TouchableOpacity
              style={styles.actionBtn}
              onPress={() => completeMutation.mutate()}
              disabled={completeMutation.isPending}
              activeOpacity={0.85}
            >
              {completeMutation.isPending
                ? <ActivityIndicator color="#fff" size="small" />
                : <><Ionicons name="checkmark-circle" size={18} color="#fff" /><Text style={styles.actionBtnText}>Mark Completed</Text></>
              }
            </TouchableOpacity>
          )}
          <TouchableOpacity
            style={[styles.actionBtn, styles.actionBtnSave]}
            onPress={() => saveMutation.mutate()}
            disabled={saveMutation.isPending}
            activeOpacity={0.85}
          >
            <Ionicons name="bookmark-outline" size={18} color={COLORS.gold} />
            <Text style={[styles.actionBtnText, { color: COLORS.gold }]}>Save Route</Text>
          </TouchableOpacity>
        </View>

        {/* Footer */}
        <Text style={styles.footer}>
          Planned {journey?.createdAt ? new Date(journey.createdAt).toLocaleDateString('en-JM', { weekday: 'long', day: 'numeric', month: 'long' }) : ''}
        </Text>
        <Text style={styles.footerSub}>ID: {id?.slice(0, 8)}...</Text>
        <View style={{ height: 40 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container:      { flex: 1, backgroundColor: COLORS.background },
  loading:        { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: COLORS.background },
  headerWrap:     { backgroundColor: COLORS.navy },
  header:         { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingBottom: 16, paddingTop: 10 },
  closeBtn:       { width: 34, height: 34, borderRadius: 10, backgroundColor: `${COLORS.white}10`, justifyContent: 'center', alignItems: 'center' },
  headerTitle:    { flex: 1, fontSize: 17, fontWeight: '700', color: '#fff', textAlign: 'center' },
  shareBtn:       { width: 34, height: 34, borderRadius: 10, backgroundColor: `${COLORS.white}10`, justifyContent: 'center', alignItems: 'center' },
  routeCard:      { margin: 16, backgroundColor: COLORS.surface, borderRadius: 20, padding: 18, borderWidth: 1, borderColor: COLORS.border },
  routeRow:       { flexDirection: 'row', alignItems: 'center', marginBottom: 18 },
  endpoint:       { flex: 1, alignItems: 'center', gap: 6 },
  dot:            { width: 10, height: 10, borderRadius: 5 },
  endpointName:   { fontSize: 13, fontWeight: '700', color: COLORS.text, textAlign: 'center' },
  arrowWrap:      { flexDirection: 'row', alignItems: 'center', gap: 2, paddingHorizontal: 8 },
  arrowLine:      { width: 20, height: 1, backgroundColor: COLORS.border },
  statsRow:       { flexDirection: 'row', borderTopWidth: 1, borderTopColor: COLORS.border, paddingTop: 14, marginBottom: 12 },
  stat:           { flex: 1, alignItems: 'center', gap: 4 },
  statDivider:    { borderRightWidth: 1, borderRightColor: COLORS.border },
  statValue:      { fontSize: 13, fontWeight: '700', color: COLORS.text },
  mlSummary:      { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: `${COLORS.teal}10`, borderRadius: 10, padding: 10 },
  mlSummaryText:  { flex: 1, fontSize: 12, color: COLORS.teal },
  mockTag:        { fontSize: 9, color: COLORS.muted, fontWeight: '700', letterSpacing: 1 },
  actions:        { paddingHorizontal: 16, gap: 10, marginBottom: 16 },
  actionBtn:      { backgroundColor: COLORS.teal, paddingVertical: 14, borderRadius: 14, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 8 },
  actionBtnSave:  { backgroundColor: `${COLORS.gold}15`, borderWidth: 1, borderColor: `${COLORS.gold}40` },
  actionBtnText:  { fontSize: 15, fontWeight: '700', color: '#fff' },
  footer:         { fontSize: 13, color: COLORS.muted, textAlign: 'center', marginBottom: 4 },
  footerSub:      { fontSize: 11, color: COLORS.border, textAlign: 'center' },
});
