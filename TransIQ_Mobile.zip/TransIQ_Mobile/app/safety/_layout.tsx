import { Stack } from 'expo-router';
export default function SafetyLayout() {
  return <Stack screenOptions={{ headerShown: false }}><Stack.Screen name="sos" /></Stack>;
}
