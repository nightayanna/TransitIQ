import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, Animated,
  Alert, Linking, Vibration, StatusBar,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useRouter, useLocalSearchParams } from 'expo-router';
import * as Location from 'expo-location';
import Toast from 'react-native-toast-message';
import { useMutation } from '@tanstack/react-query';
import { safetyApi } from '../../src/utils/api';
import { useAuthStore } from '../../src/store/authStore';
import { COLORS } from '../../src/utils/theme';

export default function SOSScreen() {
  const router   = useRouter();
  const { journeyId } = useLocalSearchParams<{ journeyId?: string }>();
  const { user } = useAuthStore();

  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [countdown, setCountdown] = useState(5);
  const [sent, setSent] = useState(false);
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const timerRef  = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    StatusBar.setBarStyle('light-content');
    Vibration.vibrate([0, 300, 200, 300]);

    // Get location immediately
    Location.requestForegroundPermissionsAsync().then(({ status }) => {
      if (status === 'granted') {
        Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High }).then(loc => {
          setLocation({ lat: loc.coords.latitude, lng: loc.coords.longitude });
        });
      }
    });

    // Pulse animation
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1.15, duration: 600, useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 1,    duration: 600, useNativeDriver: true }),
      ])
    ).start();

    // Countdown
    timerRef.current = setInterval(() => {
      setCountdown(c => {
        if (c <= 1) {
          clearInterval(timerRef.current!);
          triggerSOS();
          return 0;
        }
        return c - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      Vibration.cancel();
    };
  }, []);

  const sosMutation = useMutation({
    mutationFn: () => safetyApi.sos({
      lat:          location?.lat || 0,
      lng:          location?.lng || 0,
      contactPhone: user?.emergencyContact || '119',
      journeyId:    journeyId,
    }),
    onSuccess: () => {
      setSent(true);
      Toast.show({ type: 'success', text1: 'SOS sent!', text2: `Location sent to ${user?.emergencyContact || 'emergency contact'}` });
    },
    onError: () => {
      // Still call 119 even if backend fails
      Linking.openURL('tel:119');
    },
  });

  const triggerSOS = () => {
    sosMutation.mutate();
    // Also call 119 immediately if no emergency contact configured
    if (!user?.emergencyContact) {
      Linking.openURL('tel:119');
    }
  };

  const cancelSOS = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    Vibration.cancel();
    router.back();
  };

  return (
    <View style={styles.container}>
      <SafeAreaView style={styles.safe}>
        <TouchableOpacity style={styles.cancelBtn} onPress={cancelSOS}>
          <Ionicons name="close" size={22} color="rgba(255,255,255,0.7)" />
          <Text style={styles.cancelText}>Cancel</Text>
        </TouchableOpacity>

        <View style={styles.center}>
          {/* Pulsing SOS button */}
          <Animated.View style={[styles.pulseOuter, { transform: [{ scale: pulseAnim }] }]}>
            <TouchableOpacity style={styles.sosCircle} onPress={triggerSOS} activeOpacity={0.9}>
              <Ionicons name="warning" size={48} color="#fff" />
              <Text style={styles.sosLabel}>SOS</Text>
            </TouchableOpacity>
          </Animated.View>

          {!sent ? (
            <>
              <Text style={styles.countdownText}>
                Sending in <Text style={styles.countdownNum}>{countdown}</Text>
              </Text>
              <Text style={styles.countdownSub}>Tap to send immediately · Cancel above to stop</Text>
            </>
          ) : (
            <Text style={styles.sentText}>✓ Emergency alert sent</Text>
          )}

          {/* Location */}
          <View style={styles.locationCard}>
            <Ionicons name="location" size={16} color={COLORS.teal} />
            <Text style={styles.locationText}>
              {location
                ? `GPS: ${location.lat.toFixed(5)}, ${location.lng.toFixed(5)}`
                : 'Getting your location...'}
            </Text>
          </View>

          {/* Emergency contact */}
          <View style={styles.contactCard}>
            <Ionicons name="person-circle-outline" size={16} color={COLORS.gold} />
            <Text style={styles.contactText}>
              Alerting: {user?.emergencyContact || 'JCF Emergency (119)'}
            </Text>
          </View>
        </View>

        {/* Call 119 directly */}
        <TouchableOpacity style={styles.callBtn} onPress={() => Linking.openURL('tel:119')} activeOpacity={0.85}>
          <Ionicons name="call" size={20} color="#fff" />
          <Text style={styles.callBtnText}>Call 119 — Jamaica Constabulary Force</Text>
        </TouchableOpacity>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container:      { flex: 1, backgroundColor: '#1A0000' },
  safe:           { flex: 1, paddingHorizontal: 24, paddingVertical: 20 },
  cancelBtn:      { flexDirection: 'row', alignItems: 'center', gap: 6, alignSelf: 'flex-start', paddingVertical: 8 },
  cancelText:     { fontSize: 16, color: 'rgba(255,255,255,0.7)', fontWeight: '600' },

  center:         { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 20 },
  pulseOuter:     { width: 180, height: 180, borderRadius: 90, backgroundColor: 'rgba(220,38,38,0.2)', justifyContent: 'center', alignItems: 'center' },
  sosCircle:      { width: 148, height: 148, borderRadius: 74, backgroundColor: COLORS.sos, justifyContent: 'center', alignItems: 'center', gap: 4, borderWidth: 3, borderColor: 'rgba(255,255,255,0.3)' },
  sosLabel:       { fontSize: 32, fontWeight: '900', color: '#fff', letterSpacing: 4 },

  countdownText:  { fontSize: 22, color: '#fff', fontWeight: '600' },
  countdownNum:   { fontSize: 36, fontWeight: '900', color: COLORS.sos },
  countdownSub:   { fontSize: 13, color: 'rgba(255,255,255,0.5)', textAlign: 'center' },
  sentText:       { fontSize: 22, color: COLORS.safe, fontWeight: '700' },

  locationCard:   { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: 'rgba(255,255,255,0.08)', paddingHorizontal: 16, paddingVertical: 10, borderRadius: 12 },
  locationText:   { fontSize: 12, color: 'rgba(255,255,255,0.7)', fontFamily: 'monospace' },
  contactCard:    { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: 'rgba(255,255,255,0.06)', paddingHorizontal: 16, paddingVertical: 10, borderRadius: 12 },
  contactText:    { fontSize: 13, color: 'rgba(255,255,255,0.7)', fontWeight: '500' },

  callBtn:        { backgroundColor: '#991B1B', paddingVertical: 16, borderRadius: 14, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 8 },
  callBtnText:    { fontSize: 15, fontWeight: '700', color: '#fff' },
});
