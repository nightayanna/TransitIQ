import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Alert, TextInput,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { useQuery } from '@tanstack/react-query';
import { useRouter } from 'expo-router';
import { useAuthStore } from '../../src/store/authStore';
import { routeApi } from '../../src/utils/api';
import { COLORS } from '../../src/utils/theme';
import Toast from 'react-native-toast-message';

export default function AccountScreen() {
  const router = useRouter();
  const { user, logout, isAdmin, updateEmergencyContact } = useAuthStore();
  const [editingContact, setEditingContact] = useState(false);
  const [contactPhone, setContactPhone]     = useState(user?.emergencyContact || '');

  const { data: historyData } = useQuery({
    queryKey: ['route-history'],
    queryFn:  () => routeApi.history().then(r => r.data),
    staleTime: 1000 * 60,
  });

  const { data: savedData } = useQuery({
    queryKey: ['saved-routes'],
    queryFn:  () => routeApi.saved().then(r => r.data),
    staleTime: 1000 * 60 * 5,
  });

  const handleLogout = () => {
    Alert.alert('Log Out', 'Are you sure?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Log Out', style: 'destructive', onPress: () => { logout(); router.replace('/auth/welcome'); } },
    ]);
  };

  const saveContact = async () => {
    await updateEmergencyContact(contactPhone);
    setEditingContact(false);
    Toast.show({ type: 'success', text1: 'Emergency contact saved' });
  };

  const routes = historyData?.routes || [];
  const saved  = savedData?.routes   || [];
  const totalJmd = routes.reduce((sum: number, r: any) => sum + Number(r.fareJmd || 0), 0);

  return (
    <View style={styles.container}>
      <SafeAreaView edges={['top']} style={styles.headerWrap}>
        <View style={styles.header}>
          <Ionicons name="person-circle" size={22} color={COLORS.teal} />
          <Text style={styles.headerTitle}>Account</Text>
          {isAdmin() && (
            <TouchableOpacity style={styles.adminBtn} onPress={() => router.push('/admin')}>
              <MaterialCommunityIcons name="shield-crown" size={14} color={COLORS.gold} />
              <Text style={styles.adminBtnText}>Admin</Text>
            </TouchableOpacity>
          )}
        </View>
      </SafeAreaView>

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* User card */}
        <View style={styles.userCard}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>
              {user?.name?.split(' ').map(n => n[0]).slice(0, 2).join('') || 'T'}
            </Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.userName}>{user?.name || 'Commuter'}</Text>
            <Text style={styles.userPhone}>{user?.phone || ''}</Text>
          </View>
          {user?.role === 'admin' && (
            <View style={styles.roleBadge}>
              <Text style={styles.roleBadgeText}>Admin</Text>
            </View>
          )}
        </View>

        {/* Stats */}
        <View style={styles.statsRow}>
          {[
            { label: 'Trips',     value: routes.length },
            { label: 'Saved',     value: saved.length  },
            { label: 'Spent',     value: `JMD ${totalJmd.toLocaleString()}` },
          ].map((s, i) => (
            <View key={i} style={styles.statCard}>
              <Text style={styles.statValue}>{s.value}</Text>
              <Text style={styles.statLabel}>{s.label}</Text>
            </View>
          ))}
        </View>

        {/* Emergency contact */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Emergency Contact</Text>
          <View style={styles.sosCard}>
            <Ionicons name="warning" size={20} color={COLORS.sos} />
            <View style={{ flex: 1 }}>
              <Text style={styles.sosCardTitle}>SOS Contact</Text>
              {editingContact ? (
                <View style={styles.contactEditRow}>
                  <TextInput
                    style={styles.contactInput}
                    value={contactPhone}
                    onChangeText={setContactPhone}
                    placeholder="+18761234567"
                    placeholderTextColor={COLORS.muted}
                    keyboardType="phone-pad"
                    autoFocus
                  />
                  <TouchableOpacity onPress={saveContact} style={styles.saveBtn}>
                    <Text style={styles.saveBtnText}>Save</Text>
                  </TouchableOpacity>
                </View>
              ) : (
                <Text style={styles.contactValue}>{user?.emergencyContact || 'Not set — tap to add'}</Text>
              )}
            </View>
            <TouchableOpacity onPress={() => setEditingContact(!editingContact)}>
              <Ionicons name={editingContact ? 'close' : 'pencil'} size={18} color={COLORS.teal} />
            </TouchableOpacity>
          </View>
          <Text style={styles.sosHint}>This number receives your GPS location when you tap SOS</Text>
        </View>

        {/* Saved routes */}
        {saved.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Saved Routes</Text>
            {saved.slice(0, 5).map((r: any, i: number) => (
              <TouchableOpacity
                key={i}
                style={styles.savedRow}
                onPress={() => router.push('/tabs/plan')}
                activeOpacity={0.8}
              >
                <Ionicons name="bookmark" size={16} color={COLORS.gold} />
                <View style={{ flex: 1, marginLeft: 10 }}>
                  <Text style={styles.savedRoute} numberOfLines={1}>{r.origin} → {r.destination}</Text>
                  <Text style={styles.savedMeta}>JMD {r.fareJmd} · {r.planType}</Text>
                </View>
                <Ionicons name="navigate-outline" size={16} color={COLORS.teal} />
              </TouchableOpacity>
            ))}
          </View>
        )}

        {/* Trip history */}
        {routes.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Trip History</Text>
            {routes.slice(0, 5).map((r: any, i: number) => (
              <View key={i} style={styles.historyRow}>
                <View style={styles.historyIcon}>
                  <Ionicons name="navigate" size={14} color={COLORS.teal} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.historyRoute} numberOfLines={1}>{r.origin} → {r.destination}</Text>
                  <Text style={styles.historyMeta}>
                    {new Date(r.createdAt).toLocaleDateString('en-JM', { day: 'numeric', month: 'short' })}
                    {r.fareJmd ? ` · JMD ${r.fareJmd}` : ''}
                    {r.planType ? ` · ${r.planType}` : ''}
                  </Text>
                </View>
              </View>
            ))}
          </View>
        )}

        {/* Settings */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Settings</Text>
          <View style={styles.menuCard}>
            {[
              { icon: 'notifications-outline', label: 'Notifications' },
              { icon: 'shield-outline',         label: 'Privacy & Data' },
              { icon: 'help-circle-outline',    label: 'Help & Support' },
              { icon: 'information-circle-outline', label: 'About TransIQ' },
            ].map((item, i, arr) => (
              <TouchableOpacity key={i} style={[styles.menuRow, i < arr.length - 1 && styles.menuDivider]} activeOpacity={0.7}>
                <Ionicons name={item.icon as any} size={20} color={COLORS.textSec} />
                <Text style={styles.menuLabel}>{item.label}</Text>
                <Ionicons name="chevron-forward" size={14} color={COLORS.border} />
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Logout */}
        <View style={[styles.section, { marginBottom: 32 }]}>
          <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout} activeOpacity={0.85}>
            <Ionicons name="log-out-outline" size={18} color={COLORS.danger} />
            <Text style={styles.logoutText}>Log Out</Text>
          </TouchableOpacity>
          <Text style={styles.versionText}>TransIQ v1.0.0 · Intellibus Hackathon 2026</Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container:      { flex: 1, backgroundColor: COLORS.background },
  headerWrap:     { backgroundColor: COLORS.navy },
  header:         { flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 20, paddingBottom: 16, paddingTop: 10 },
  headerTitle:    { flex: 1, fontSize: 22, fontWeight: '800', color: COLORS.text },
  adminBtn:       { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: `${COLORS.gold}20`, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 20 },
  adminBtnText:   { fontSize: 12, color: COLORS.gold, fontWeight: '700' },

  userCard:       { margin: 16, backgroundColor: COLORS.surface, borderRadius: 18, padding: 18, flexDirection: 'row', alignItems: 'center', gap: 14, borderWidth: 1, borderColor: COLORS.border },
  avatar:         { width: 56, height: 56, borderRadius: 16, backgroundColor: COLORS.teal, justifyContent: 'center', alignItems: 'center' },
  avatarText:     { fontSize: 20, fontWeight: '800', color: '#fff' },
  userName:       { fontSize: 17, fontWeight: '800', color: COLORS.text },
  userPhone:      { fontSize: 13, color: COLORS.textSec, marginTop: 3 },
  roleBadge:      { backgroundColor: `${COLORS.gold}20`, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20 },
  roleBadgeText:  { fontSize: 12, color: COLORS.gold, fontWeight: '700' },

  statsRow:       { flexDirection: 'row', gap: 10, paddingHorizontal: 16, marginBottom: 20 },
  statCard:       { flex: 1, backgroundColor: COLORS.surface, borderRadius: 14, padding: 14, alignItems: 'center', borderWidth: 1, borderColor: COLORS.border },
  statValue:      { fontSize: 15, fontWeight: '800', color: COLORS.text },
  statLabel:      { fontSize: 11, color: COLORS.muted, marginTop: 4 },

  section:        { paddingHorizontal: 16, marginBottom: 20 },
  sectionTitle:   { fontSize: 17, fontWeight: '700', color: COLORS.text, marginBottom: 12 },

  sosCard:        { backgroundColor: `${COLORS.sos}10`, borderRadius: 14, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 12, borderWidth: 1, borderColor: `${COLORS.sos}30` },
  sosCardTitle:   { fontSize: 14, fontWeight: '700', color: COLORS.text, marginBottom: 4 },
  contactValue:   { fontSize: 13, color: COLORS.textSec },
  contactEditRow: { flexDirection: 'row', gap: 8, alignItems: 'center' },
  contactInput:   { flex: 1, fontSize: 14, color: COLORS.text, borderBottomWidth: 1, borderBottomColor: COLORS.teal, paddingVertical: 4 },
  saveBtn:        { backgroundColor: COLORS.teal, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8 },
  saveBtnText:    { fontSize: 13, color: '#fff', fontWeight: '700' },
  sosHint:        { fontSize: 11, color: COLORS.muted, marginTop: 8 },

  savedRow:       { backgroundColor: COLORS.surface, borderRadius: 12, padding: 12, flexDirection: 'row', alignItems: 'center', marginBottom: 8, borderWidth: 1, borderColor: COLORS.border },
  savedRoute:     { fontSize: 13, fontWeight: '600', color: COLORS.text },
  savedMeta:      { fontSize: 11, color: COLORS.muted, marginTop: 2 },

  historyRow:     { backgroundColor: COLORS.surface, borderRadius: 12, padding: 12, flexDirection: 'row', alignItems: 'center', marginBottom: 8, borderWidth: 1, borderColor: COLORS.border },
  historyIcon:    { width: 32, height: 32, borderRadius: 10, backgroundColor: `${COLORS.teal}20`, justifyContent: 'center', alignItems: 'center' },
  historyRoute:   { fontSize: 13, fontWeight: '600', color: COLORS.text, marginLeft: 10 },
  historyMeta:    { fontSize: 11, color: COLORS.muted, marginLeft: 10, marginTop: 2 },

  menuCard:       { backgroundColor: COLORS.surface, borderRadius: 16, overflow: 'hidden', borderWidth: 1, borderColor: COLORS.border },
  menuRow:        { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 16, paddingVertical: 14 },
  menuDivider:    { borderBottomWidth: 1, borderBottomColor: COLORS.border },
  menuLabel:      { flex: 1, fontSize: 15, color: COLORS.textSec, fontWeight: '500' },

  logoutBtn:      { backgroundColor: `${COLORS.danger}15`, paddingVertical: 14, borderRadius: 14, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 8, marginBottom: 14, borderWidth: 1, borderColor: `${COLORS.danger}30` },
  logoutText:     { fontSize: 15, fontWeight: '700', color: COLORS.danger },
  versionText:    { fontSize: 11, color: COLORS.muted, textAlign: 'center' },
});
