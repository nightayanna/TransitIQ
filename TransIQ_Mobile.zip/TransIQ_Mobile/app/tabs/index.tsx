import React, { useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  RefreshControl, Dimensions,
} from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { useQuery } from '@tanstack/react-query';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuthStore } from '../../src/store/authStore';
import { analyticsApi, routeApi, adminApi } from '../../src/utils/api';
import { COLORS } from '../../src/utils/theme';

const { width } = Dimensions.get('window');

const QUICK_ACTIONS = [
  { icon: 'navigate',     label: 'Plan Trip',    route: '/tabs/plan',   color: COLORS.teal,    bg: `${COLORS.teal}20`    },
  { icon: 'map',          label: 'Live Map',     route: '/tabs/map',    color: COLORS.express, bg: `${COLORS.express}20` },
  { icon: 'shield-checkmark', label: 'Safety',   route: '/tabs/safety', color: COLORS.safe,    bg: `${COLORS.safe}20`    },
  { icon: 'time',         label: 'History',      route: '/tabs/account',color: COLORS.gold,    bg: `${COLORS.gold}20`    },
];

const POPULAR = [
  { from: 'Spanish Town',  to: 'Downtown Kingston', type: 'Bus',     fare: 'JMD 100',   icon: 'bus',       color: COLORS.bus     },
  { from: 'Half Way Tree', to: 'Papine',             type: 'Taxi',    fare: 'JMD 150',   icon: 'taxi',      color: COLORS.taxi    },
  { from: 'Downtown',      to: 'Portmore',           type: 'Bus',     fare: 'JMD 100',   icon: 'bus',       color: COLORS.bus     },
  { from: 'Kingston',      to: 'Montego Bay',        type: 'Express', fare: 'JMD 3,900', icon: 'bus-coach', color: COLORS.express },
  { from: 'New Kingston',  to: 'Airport (NMIA)',     type: 'JUTA',    fare: 'JMD 4,500', icon: 'leaf',      color: COLORS.juta    },
  { from: 'New Kingston',  to: 'Airport (NMIA)',     type: 'Uber',    fare: '~JMD 6,000',icon: 'car',       color: COLORS.uber    },
];

export default function HomeScreen() {
  const router = useRouter();
  const { user } = useAuthStore();

  const { data: impactData, refetch, isRefetching } = useQuery({
    queryKey: ['impact'],
    queryFn:  () => analyticsApi.impact().then(r => r.data),
    staleTime: 1000 * 60 * 2,
  });

  const { data: historyData } = useQuery({
    queryKey: ['route-history'],
    queryFn:  () => routeApi.history().then(r => r.data),
    staleTime: 1000 * 60,
  });

  const { data: mlStatus } = useQuery({
    queryKey: ['ml-status'],
    queryFn:  () => adminApi.mlStatus().then(r => r.data),
    staleTime: 1000 * 30,
  });

  const onRefresh = useCallback(() => refetch(), []);
  const firstName = user?.name?.split(' ')[0] || 'Commuter';
  const recent    = historyData?.routes?.slice(0, 3) || [];

  return (
    <View style={styles.container}>
      {/* Header */}
      <LinearGradient colors={[COLORS.navy, COLORS.navyLight]} style={styles.header}>
        <SafeAreaView edges={['top']}>
          <View style={styles.headerInner}>
            <View>
              <Text style={styles.greeting}>Good morning 👋</Text>
              <Text style={styles.userName}>{firstName}</Text>
            </View>
            <View style={styles.headerRight}>
              {/* Kafka live indicator */}
              <View style={styles.liveBadge}>
                <View style={styles.livePulse} />
                <Text style={styles.liveText}>LIVE</Text>
              </View>
              <TouchableOpacity style={styles.notifBtn}>
                <Ionicons name="notifications-outline" size={22} color="#fff" />
              </TouchableOpacity>
            </View>
          </View>
        </SafeAreaView>
      </LinearGradient>

      <ScrollView
        style={styles.scroll}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={isRefetching} onRefresh={onRefresh} tintColor={COLORS.teal} />}
      >
        {/* Search shortcut - Uber style "Where to?" */}
        <TouchableOpacity style={styles.searchBar} onPress={() => router.push('/tabs/plan')} activeOpacity={0.8}>
          <View style={styles.searchIcon}>
            <Ionicons name="search" size={18} color={COLORS.teal} />
          </View>
          <Text style={styles.searchText}>Where to?</Text>
          <View style={styles.searchBudgetBtn}>
            <Ionicons name="options-outline" size={16} color={COLORS.textSec} />
          </View>
        </TouchableOpacity>

        {/* Quick actions */}
        <View style={styles.section}>
          <View style={styles.actionRow}>
            {QUICK_ACTIONS.map((a, i) => (
              <TouchableOpacity key={i} style={styles.actionCard} onPress={() => router.push(a.route as any)} activeOpacity={0.8}>
                <View style={[styles.actionIcon, { backgroundColor: a.bg }]}>
                  <Ionicons name={a.icon as any} size={22} color={a.color} />
                </View>
                <Text style={styles.actionLabel}>{a.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* ML Status indicator */}
        {mlStatus && (
          <View style={styles.section}>
            <View style={styles.mlStatusCard}>
              <MaterialCommunityIcons name="brain" size={18} color={mlStatus.allLive ? COLORS.teal : COLORS.gold} />
              <Text style={[styles.mlStatusText, { color: mlStatus.allLive ? COLORS.teal : COLORS.gold }]}>
                {mlStatus.allLive ? 'ML models live — predictions powered by Lambda' : 'ML models in mock mode — synthetic predictions active'}
              </Text>
              <View style={[styles.mlDot, { backgroundColor: mlStatus.allLive ? COLORS.teal : COLORS.gold }]} />
            </View>
          </View>
        )}

        {/* Impact stats (Snowflake) */}
        {impactData && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Today's Impact</Text>
            <View style={styles.statsCard}>
              {[
                { label: 'Trips Planned', value: impactData.tripsToday    || '—', icon: 'navigate-outline' },
                { label: 'Avg Time Saved', value: impactData.avgTimeSaved  ? `${impactData.avgTimeSaved}m` : '—', icon: 'time-outline' },
                { label: 'Avg Money Saved', value: impactData.avgMoneySaved ? `JMD ${impactData.avgMoneySaved}` : '—', icon: 'cash-outline' },
              ].map((s, i) => (
                <View key={i} style={[styles.statItem, i < 2 && styles.statDivider]}>
                  <Ionicons name={s.icon as any} size={18} color={COLORS.teal} />
                  <Text style={styles.statValue}>{s.value}</Text>
                  <Text style={styles.statLabel}>{s.label}</Text>
                </View>
              ))}
            </View>
          </View>
        )}

        {/* Popular routes - all 5 transport types */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Popular Routes</Text>
          {POPULAR.map((r, i) => (
            <TouchableOpacity key={i} style={styles.routeCard} onPress={() => router.push('/tabs/plan')} activeOpacity={0.8}>
              <View style={[styles.routeIcon, { backgroundColor: `${r.color}20` }]}>
                <MaterialCommunityIcons name={r.icon as any} size={20} color={r.color} />
              </View>
              <View style={styles.routeInfo}>
                <Text style={styles.routeFrom} numberOfLines={1}>{r.from}</Text>
                <View style={styles.routeArrow}>
                  <View style={styles.routeLine} />
                  <Ionicons name="arrow-forward" size={10} color={COLORS.muted} />
                </View>
                <Text style={styles.routeTo} numberOfLines={1}>{r.to}</Text>
              </View>
              <View style={styles.routeMeta}>
                <Text style={styles.routeFare}>{r.fare}</Text>
                <Text style={[styles.routeType, { color: r.color }]}>{r.type}</Text>
              </View>
            </TouchableOpacity>
          ))}
        </View>

        {/* Recent trips */}
        {recent.length > 0 && (
          <View style={[styles.section, { marginBottom: 24 }]}>
            <Text style={styles.sectionTitle}>Recent Trips</Text>
            {recent.map((r: any, i: number) => (
              <View key={i} style={styles.recentRow}>
                <Ionicons name="time-outline" size={16} color={COLORS.teal} />
                <View style={{ flex: 1, marginLeft: 10 }}>
                  <Text style={styles.recentRoute} numberOfLines={1}>{r.origin} → {r.destination}</Text>
                  <Text style={styles.recentMeta}>{new Date(r.createdAt).toLocaleDateString()} · JMD {r.fareJmd}</Text>
                </View>
                <Text style={[styles.planTypeBadge, { color: r.planType === 'fastest' ? COLORS.teal : r.planType === 'cheapest' ? COLORS.safe : COLORS.express }]}>
                  {r.planType}
                </Text>
              </View>
            ))}
          </View>
        )}

        <View style={{ height: 20 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container:      { flex: 1, backgroundColor: COLORS.background },
  header:         { paddingBottom: 20 },
  headerInner:    { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingTop: 10 },
  greeting:       { fontSize: 13, color: COLORS.textSec },
  userName:       { fontSize: 24, fontWeight: '800', color: COLORS.text, marginTop: 2 },
  headerRight:    { flexDirection: 'row', alignItems: 'center', gap: 10 },
  liveBadge:      { flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: `${COLORS.teal}20`, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 20, borderWidth: 1, borderColor: `${COLORS.teal}30` },
  livePulse:      { width: 6, height: 6, borderRadius: 3, backgroundColor: COLORS.teal },
  liveText:       { fontSize: 10, color: COLORS.teal, fontWeight: '800', letterSpacing: 1 },
  notifBtn:       { width: 36, height: 36, borderRadius: 10, backgroundColor: `${COLORS.white}10`, justifyContent: 'center', alignItems: 'center' },

  scroll:         { flex: 1 },
  searchBar:      { margin: 16, backgroundColor: COLORS.surface, borderRadius: 14, flexDirection: 'row', alignItems: 'center', padding: 4, borderWidth: 1, borderColor: COLORS.border },
  searchIcon:     { width: 40, height: 40, borderRadius: 10, backgroundColor: `${COLORS.teal}20`, justifyContent: 'center', alignItems: 'center' },
  searchText:     { flex: 1, fontSize: 16, color: COLORS.muted, marginLeft: 12 },
  searchBudgetBtn:{ width: 36, height: 36, justifyContent: 'center', alignItems: 'center' },

  section:        { paddingHorizontal: 16, marginBottom: 20 },
  sectionTitle:   { fontSize: 17, fontWeight: '700', color: COLORS.text, marginBottom: 12 },
  actionRow:      { flexDirection: 'row', gap: 10 },
  actionCard:     { flex: 1, backgroundColor: COLORS.surface, borderRadius: 14, padding: 14, alignItems: 'center', gap: 8, borderWidth: 1, borderColor: COLORS.border },
  actionIcon:     { width: 44, height: 44, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
  actionLabel:    { fontSize: 11, fontWeight: '600', color: COLORS.textSec, textAlign: 'center' },

  mlStatusCard:   { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: COLORS.surface, borderRadius: 12, padding: 12, borderWidth: 1, borderColor: COLORS.border },
  mlStatusText:   { flex: 1, fontSize: 12, fontWeight: '500' },
  mlDot:          { width: 8, height: 8, borderRadius: 4 },

  statsCard:      { backgroundColor: COLORS.surface, borderRadius: 16, padding: 16, flexDirection: 'row', borderWidth: 1, borderColor: COLORS.border },
  statItem:       { flex: 1, alignItems: 'center', gap: 4 },
  statDivider:    { borderRightWidth: 1, borderRightColor: COLORS.border },
  statValue:      { fontSize: 16, fontWeight: '800', color: COLORS.text },
  statLabel:      { fontSize: 10, color: COLORS.textSec, textAlign: 'center' },

  routeCard:      { backgroundColor: COLORS.surface, borderRadius: 12, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 8, borderWidth: 1, borderColor: COLORS.border },
  routeIcon:      { width: 40, height: 40, borderRadius: 10, justifyContent: 'center', alignItems: 'center' },
  routeInfo:      { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 4 },
  routeFrom:      { fontSize: 12, fontWeight: '600', color: COLORS.text, flex: 1 },
  routeArrow:     { flexDirection: 'row', alignItems: 'center', gap: 1 },
  routeLine:      { width: 12, height: 1, backgroundColor: COLORS.border },
  routeTo:        { fontSize: 12, color: COLORS.textSec, flex: 1 },
  routeMeta:      { alignItems: 'flex-end' },
  routeFare:      { fontSize: 13, fontWeight: '700', color: COLORS.text },
  routeType:      { fontSize: 10, fontWeight: '600', marginTop: 2 },

  recentRow:      { backgroundColor: COLORS.surface, borderRadius: 12, padding: 12, flexDirection: 'row', alignItems: 'center', marginBottom: 8, borderWidth: 1, borderColor: COLORS.border },
  recentRoute:    { fontSize: 13, fontWeight: '600', color: COLORS.text },
  recentMeta:     { fontSize: 11, color: COLORS.textSec, marginTop: 2 },
  planTypeBadge:  { fontSize: 11, fontWeight: '700', textTransform: 'capitalize' },
});
