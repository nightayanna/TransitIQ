import React, { useState, useRef } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, Dimensions,
} from 'react-native';
import MapView, { Polyline, Marker, PROVIDER_GOOGLE } from 'react-native-maps';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { COLORS } from '../../src/utils/theme';

const { width, height } = Dimensions.get('window');

// Congestion colour mapping — driven by ML Model 3 output
const CONGESTION_COLORS = {
  clear:    COLORS.safe,
  moderate: COLORS.gold,
  heavy:    COLORS.danger,
};

// Kingston, Jamaica centre
const KINGSTON_REGION = {
  latitude:      17.9973,
  longitude:    -76.7946,
  latitudeDelta:  0.08,
  longitudeDelta: 0.08,
};

export default function MapScreen() {
  const router   = useRouter();
  const mapRef   = useRef<MapView>(null);
  const [mapType, setMapType] = useState<'standard' | 'satellite'>('standard');

  // In production: active journey legs with congestion scores come from Kafka
  // via the Spring Boot WebSocket → React Native state. Hardcoded here for demo.
  const demoRoute = {
    legs: [
      {
        points:     [{ latitude: 17.9973, longitude: -76.7946 }, { latitude: 18.01, longitude: -76.79 }],
        congestion: 'moderate' as const,
        type:       'bus',
        label:      'Spanish Town Rd',
      },
      {
        points:     [{ latitude: 18.01, longitude: -76.79 }, { latitude: 17.997, longitude: -76.794 }],
        congestion: 'clear' as const,
        type:       'taxi',
        label:      'Half Way Tree',
      },
    ],
  };

  return (
    <View style={styles.container}>
      {/* Map */}
      <MapView
        ref={mapRef}
        provider={PROVIDER_GOOGLE}
        style={styles.map}
        initialRegion={KINGSTON_REGION}
        mapType={mapType}
        showsUserLocation
        showsMyLocationButton={false}
        customMapStyle={darkMapStyle}
      >
        {/* Route segments coloured by ML congestion score */}
        {demoRoute.legs.map((leg, i) => (
          <Polyline
            key={i}
            coordinates={leg.points}
            strokeColor={CONGESTION_COLORS[leg.congestion]}
            strokeWidth={5}
            lineDashPattern={leg.type === 'walk' ? [8, 4] : undefined}
          />
        ))}

        {/* Origin marker */}
        <Marker coordinate={{ latitude: 17.9973, longitude: -76.7946 }} title="Spanish Town" description="Origin">
          <View style={styles.originMarker}>
            <Ionicons name="radio-button-on" size={20} color={COLORS.teal} />
          </View>
        </Marker>

        {/* Destination marker */}
        <Marker coordinate={{ latitude: 17.997, longitude: -76.794 }} title="Downtown Kingston" description="Destination">
          <View style={styles.destMarker}>
            <Ionicons name="location" size={24} color={COLORS.sos} />
          </View>
        </Marker>
      </MapView>

      {/* Header overlay */}
      <SafeAreaView edges={['top']} style={styles.headerOverlay} pointerEvents="box-none">
        <View style={styles.header}>
          <View style={styles.headerLeft}>
            <MaterialCommunityIcons name="brain" size={16} color={COLORS.teal} />
            <Text style={styles.headerTitle}>Live Map</Text>
            <Text style={styles.headerSub}>ML congestion colours</Text>
          </View>
          <TouchableOpacity style={styles.mapTypeBtn} onPress={() => setMapType(t => t === 'standard' ? 'satellite' : 'standard')}>
            <Ionicons name="layers-outline" size={18} color="#fff" />
          </TouchableOpacity>
        </View>
      </SafeAreaView>

      {/* Legend overlay */}
      <View style={styles.legend} pointerEvents="none">
        <Text style={styles.legendTitle}>Congestion</Text>
        {Object.entries(CONGESTION_COLORS).map(([label, color]) => (
          <View key={label} style={styles.legendRow}>
            <View style={[styles.legendDot, { backgroundColor: color }]} />
            <Text style={styles.legendLabel}>{label}</Text>
          </View>
        ))}
        <Text style={styles.legendSub}>Model 3</Text>
      </View>

      {/* My location + SOS buttons */}
      <View style={styles.fab} pointerEvents="box-none">
        {/* SOS button */}
        <TouchableOpacity style={styles.sosFab} onPress={() => router.push('/safety/sos')} activeOpacity={0.85}>
          <Ionicons name="warning" size={18} color="#fff" />
          <Text style={styles.sosFabText}>SOS</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.locFab}
          onPress={() => mapRef.current?.animateToRegion(KINGSTON_REGION, 800)}
          activeOpacity={0.85}
        >
          <Ionicons name="locate" size={20} color={COLORS.teal} />
        </TouchableOpacity>
      </View>

      {/* Plan trip button */}
      <TouchableOpacity style={styles.planBtn} onPress={() => router.push('/tabs/plan')} activeOpacity={0.85}>
        <Ionicons name="navigate" size={18} color="#fff" />
        <Text style={styles.planBtnText}>Plan a Trip</Text>
      </TouchableOpacity>
    </View>
  );
}

// Google Maps dark style
const darkMapStyle = [
  { elementType: 'geometry', stylers: [{ color: '#0D1B2E' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#94A3B8' }] },
  { elementType: 'labels.text.stroke', stylers: [{ color: '#0D1B2E' }] },
  { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#1E3A5F' }] },
  { featureType: 'road.highway', elementType: 'geometry', stylers: [{ color: '#1A3A5C' }] },
  { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#060F1E' }] },
  { featureType: 'poi', stylers: [{ visibility: 'off' }] },
];

const styles = StyleSheet.create({
  container:      { flex: 1 },
  map:            { width, height },

  headerOverlay:  { position: 'absolute', top: 0, left: 0, right: 0 },
  header:         { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 12, backgroundColor: 'rgba(10,35,66,0.85)', margin: 12, borderRadius: 14, borderWidth: 1, borderColor: COLORS.border },
  headerLeft:     { flexDirection: 'row', alignItems: 'center', gap: 6 },
  headerTitle:    { fontSize: 15, fontWeight: '700', color: COLORS.text },
  headerSub:      { fontSize: 11, color: COLORS.teal },
  mapTypeBtn:     { width: 32, height: 32, borderRadius: 8, backgroundColor: `${COLORS.teal}20`, justifyContent: 'center', alignItems: 'center' },

  legend:         { position: 'absolute', top: 110, left: 16, backgroundColor: 'rgba(13,27,46,0.9)', borderRadius: 12, padding: 10, borderWidth: 1, borderColor: COLORS.border },
  legendTitle:    { fontSize: 11, fontWeight: '700', color: COLORS.textSec, marginBottom: 6, textTransform: 'uppercase', letterSpacing: 0.5 },
  legendRow:      { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 4 },
  legendDot:      { width: 10, height: 4, borderRadius: 2 },
  legendLabel:    { fontSize: 11, color: COLORS.textSec, textTransform: 'capitalize' },
  legendSub:      { fontSize: 9, color: COLORS.muted, marginTop: 4 },

  fab:            { position: 'absolute', bottom: 100, right: 16, gap: 10 },
  sosFab:         { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: COLORS.sos, paddingHorizontal: 12, paddingVertical: 10, borderRadius: 12 },
  sosFabText:     { fontSize: 13, fontWeight: '800', color: '#fff' },
  locFab:         { width: 44, height: 44, borderRadius: 12, backgroundColor: 'rgba(13,27,46,0.9)', justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: COLORS.border },

  planBtn:        { position: 'absolute', bottom: 24, left: 24, right: 24, backgroundColor: COLORS.teal, paddingVertical: 14, borderRadius: 14, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 8 },
  planBtnText:    { fontSize: 16, fontWeight: '700', color: '#fff' },

  originMarker:   { alignItems: 'center', justifyContent: 'center' },
  destMarker:     { alignItems: 'center', justifyContent: 'center' },
});
