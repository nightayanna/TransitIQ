import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  TextInput, ActivityIndicator, KeyboardAvoidingView, Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { useMutation } from '@tanstack/react-query';
import * as Location from 'expo-location';
import { LinearGradient } from 'expo-linear-gradient';
import Toast from 'react-native-toast-message';
import { useRouter } from 'expo-router';
import { routeApi } from '../../src/utils/api';
import { COLORS } from '../../src/utils/theme';
import { PlanCard } from '../../src/types/ml';
import PlanResultCard from '../../src/components/PlanResultCard';

const PLAN_TYPES: { key: 'fastest' | 'cheapest' | 'balanced'; label: string; icon: string; desc: string; color: string }[] = [
  { key: 'fastest',  label: 'Fastest',  icon: 'flash',     desc: 'Least time',    color: COLORS.fastest  },
  { key: 'cheapest', label: 'Cheapest', icon: 'cash',      desc: 'Lowest fare',   color: COLORS.cheapest },
  { key: 'balanced', label: 'Balanced', icon: 'git-merge', desc: 'Best of both',  color: COLORS.balanced },
];

// Quick location options for the demo scenario
const QUICK_LOCATIONS = [
  'Spanish Town', 'Half Way Tree', 'Downtown Kingston',
  'New Kingston',  'Portmore',     'Papine', 'National Arena',
];

export default function PlanScreen() {
  const router = useRouter();
  const [origin, setOrigin]     = useState('');
  const [dest, setDest]         = useState('');
  const [budgetJmd, setBudget]  = useState('');
  const [time, setTime]         = useState('');
  const [pref, setPref]         = useState<'fastest' | 'cheapest' | 'balanced'>('fastest');
  const [plans, setPlans]       = useState<PlanCard[]>([]);
  const [gettingLoc, setGettingLoc] = useState(false);

  const planMutation = useMutation({
    mutationFn: () => routeApi.plan({
      origin,
      destination: dest,
      departTime:  time || new Date().toISOString(),
      budgetJmd:   budgetJmd ? parseInt(budgetJmd) : undefined,
      preference:  pref,
    }),
    onSuccess: (res) => {
      const { plans: newPlans, message } = res.data;
      if (!newPlans?.length) {
        Toast.show({ type: 'info', text1: message || 'No routes found' });
        setPlans([]);
      } else {
        setPlans(newPlans);
      }
    },
    onError: (err: any) => {
      Toast.show({ type: 'error', text1: err.response?.data?.message || 'Planning failed' });
    },
  });

  const useMyLocation = async () => {
    setGettingLoc(true);
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') { Toast.show({ type: 'error', text1: 'Location permission denied' }); return; }
      const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const geo = await Location.reverseGeocodeAsync(loc.coords);
      const label = geo[0] ? [geo[0].name, geo[0].district].filter(Boolean).join(', ') : 'My Location';
      setOrigin(label);
    } finally {
      setGettingLoc(false);
    }
  };

  const canPlan = origin.trim().length > 0 && dest.trim().length > 0;

  return (
    <View style={styles.container}>
      <SafeAreaView edges={['top']} style={styles.headerWrap}>
        <View style={styles.header}>
          <MaterialCommunityIcons name="brain" size={22} color={COLORS.teal} />
          <Text style={styles.headerTitle}>Plan Trip</Text>
          <Text style={styles.headerSub}>AI-powered · 3 plans</Text>
        </View>
      </SafeAreaView>

      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
        <ScrollView style={styles.scroll} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          {/* Route inputs */}
          <View style={styles.inputCard}>
            {/* Origin */}
            <View style={styles.inputRow}>
              <View style={[styles.routeDot, { backgroundColor: COLORS.teal }]} />
              <View style={styles.inputField}>
                <TextInput
                  style={styles.input}
                  placeholder="From — where are you?"
                  placeholderTextColor={COLORS.muted}
                  value={origin}
                  onChangeText={setOrigin}
                />
                <TouchableOpacity onPress={useMyLocation} disabled={gettingLoc}>
                  {gettingLoc
                    ? <ActivityIndicator size="small" color={COLORS.teal} />
                    : <Ionicons name="locate" size={18} color={COLORS.teal} />
                  }
                </TouchableOpacity>
              </View>
            </View>

            <View style={styles.dashedLine} />

            {/* Destination */}
            <View style={styles.inputRow}>
              <View style={[styles.routeDot, { backgroundColor: COLORS.gold }]} />
              <View style={styles.inputField}>
                <TextInput
                  style={styles.input}
                  placeholder="To — where are you going?"
                  placeholderTextColor={COLORS.muted}
                  value={dest}
                  onChangeText={setDest}
                />
              </View>
            </View>

            {/* Budget + time row */}
            <View style={styles.filtersRow}>
              <View style={styles.filterInput}>
                <Ionicons name="cash-outline" size={14} color={COLORS.muted} />
                <TextInput
                  style={styles.filterText}
                  placeholder="Budget (JMD)"
                  placeholderTextColor={COLORS.muted}
                  value={budgetJmd}
                  onChangeText={setBudget}
                  keyboardType="number-pad"
                />
              </View>
              <View style={styles.filterInput}>
                <Ionicons name="time-outline" size={14} color={COLORS.muted} />
                <TextInput
                  style={styles.filterText}
                  placeholder="Leave time"
                  placeholderTextColor={COLORS.muted}
                  value={time}
                  onChangeText={setTime}
                />
              </View>
            </View>
          </View>

          {/* Quick picks */}
          <View style={styles.section}>
            <Text style={styles.sectionLabel}>Quick pick origin:</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              <View style={{ flexDirection: 'row', gap: 8 }}>
                {QUICK_LOCATIONS.map((l, i) => (
                  <TouchableOpacity key={i} style={[styles.chip, origin === l && styles.chipActive]} onPress={() => setOrigin(l)}>
                    <Text style={[styles.chipText, origin === l && styles.chipTextActive]}>{l}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </ScrollView>
            <Text style={[styles.sectionLabel, { marginTop: 10 }]}>Quick pick destination:</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              <View style={{ flexDirection: 'row', gap: 8 }}>
                {QUICK_LOCATIONS.filter(l => l !== origin).map((l, i) => (
                  <TouchableOpacity key={i} style={[styles.chip, dest === l && styles.chipActive]} onPress={() => setDest(l)}>
                    <Text style={[styles.chipText, dest === l && styles.chipTextActive]}>{l}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </ScrollView>
          </View>

          {/* Plan type selector */}
          <View style={styles.section}>
            <Text style={styles.sectionLabel}>Optimise for:</Text>
            <View style={styles.prefRow}>
              {PLAN_TYPES.map(p => (
                <TouchableOpacity
                  key={p.key}
                  style={[styles.prefCard, pref === p.key && { borderColor: p.color, backgroundColor: `${p.color}15` }]}
                  onPress={() => setPref(p.key)}
                  activeOpacity={0.8}
                >
                  <Ionicons name={p.icon as any} size={20} color={pref === p.key ? p.color : COLORS.muted} />
                  <Text style={[styles.prefLabel, pref === p.key && { color: p.color }]}>{p.label}</Text>
                  <Text style={styles.prefDesc}>{p.desc}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          {/* Plan button */}
          <View style={styles.section}>
            <TouchableOpacity
              style={[styles.planBtn, (!canPlan || planMutation.isPending) && styles.planBtnDisabled]}
              onPress={() => planMutation.mutate()}
              disabled={!canPlan || planMutation.isPending}
              activeOpacity={0.85}
            >
              <LinearGradient
                colors={canPlan ? [COLORS.teal, '#0B7A6E'] : [COLORS.surface, COLORS.surface]}
                style={styles.planBtnGradient}
                start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
              >
                {planMutation.isPending
                  ? <><ActivityIndicator color="#fff" size="small" /><Text style={styles.planBtnText}>Finding best routes...</Text></>
                  : <><MaterialCommunityIcons name="brain" size={20} color={canPlan ? '#fff' : COLORS.muted} /><Text style={[styles.planBtnText, !canPlan && { color: COLORS.muted }]}>Find AI-Powered Routes</Text></>
                }
              </LinearGradient>
            </TouchableOpacity>
            {!canPlan && <Text style={styles.planHint}>Enter both origin and destination above</Text>}
          </View>

          {/* Results - 3 plan cards */}
          {plans.length > 0 && (
            <View style={styles.section}>
              <View style={styles.resultsHeader}>
                <Text style={styles.resultsTitle}>{plans.length} plans found</Text>
                <Text style={styles.resultsSub}>ML predictions · live traffic applied</Text>
              </View>
              {plans.map((plan, i) => (
                <PlanResultCard
                  key={i}
                  plan={plan}
                  index={i}
                  onViewDetail={(id) => router.push(`/journey/${id}`)}
                />
              ))}
            </View>
          )}

          <View style={{ height: 30 }} />
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  container:      { flex: 1, backgroundColor: COLORS.background },
  headerWrap:     { backgroundColor: COLORS.navy },
  header:         { paddingHorizontal: 20, paddingBottom: 16, paddingTop: 10 },
  headerTitle:    { fontSize: 22, fontWeight: '800', color: COLORS.text, marginTop: 4 },
  headerSub:      { fontSize: 12, color: COLORS.teal, marginTop: 2 },
  scroll:         { flex: 1 },

  inputCard:      { margin: 16, backgroundColor: COLORS.surface, borderRadius: 18, padding: 16, borderWidth: 1, borderColor: COLORS.border },
  inputRow:       { flexDirection: 'row', alignItems: 'center', gap: 12 },
  routeDot:       { width: 12, height: 12, borderRadius: 6 },
  inputField:     { flex: 1, flexDirection: 'row', alignItems: 'center', borderBottomWidth: 1, borderBottomColor: COLORS.border, paddingBottom: 10 },
  input:          { flex: 1, fontSize: 15, color: COLORS.text, paddingVertical: 4 },
  dashedLine:     { marginLeft: 18, marginVertical: 8, height: 20, borderLeftWidth: 1.5, borderLeftColor: COLORS.border, borderStyle: 'dashed' },
  filtersRow:     { flexDirection: 'row', gap: 10, marginTop: 14 },
  filterInput:    { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: COLORS.background, borderRadius: 10, paddingHorizontal: 10, paddingVertical: 8, borderWidth: 1, borderColor: COLORS.border },
  filterText:     { flex: 1, fontSize: 13, color: COLORS.text },

  section:        { paddingHorizontal: 16, marginBottom: 16 },
  sectionLabel:   { fontSize: 12, fontWeight: '600', color: COLORS.muted, marginBottom: 8, textTransform: 'uppercase', letterSpacing: 0.5 },
  chip:           { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border },
  chipActive:     { backgroundColor: COLORS.teal, borderColor: COLORS.teal },
  chipText:       { fontSize: 13, color: COLORS.textSec, fontWeight: '600' },
  chipTextActive: { color: '#fff' },

  prefRow:        { flexDirection: 'row', gap: 10 },
  prefCard:       { flex: 1, backgroundColor: COLORS.surface, borderRadius: 12, padding: 12, alignItems: 'center', gap: 4, borderWidth: 1.5, borderColor: COLORS.border },
  prefLabel:      { fontSize: 13, fontWeight: '700', color: COLORS.textSec },
  prefDesc:       { fontSize: 10, color: COLORS.muted, textAlign: 'center' },

  planBtn:        { borderRadius: 14, overflow: 'hidden' },
  planBtnDisabled:{ opacity: 0.5 },
  planBtnGradient:{ paddingVertical: 16, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 8 },
  planBtnText:    { fontSize: 16, fontWeight: '700', color: '#fff' },
  planHint:       { fontSize: 12, color: COLORS.muted, textAlign: 'center', marginTop: 8 },

  resultsHeader:  { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 12 },
  resultsTitle:   { fontSize: 17, fontWeight: '700', color: COLORS.text },
  resultsSub:     { fontSize: 12, color: COLORS.teal },
});
