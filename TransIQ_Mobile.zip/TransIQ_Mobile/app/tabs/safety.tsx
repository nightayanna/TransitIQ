import React from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Linking, ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useQuery } from '@tanstack/react-query';
import { useRouter } from 'expo-router';
import { safetyApi } from '../../src/utils/api';
import { COLORS } from '../../src/utils/theme';

const ZONE_CFG = {
  safe:    { color: COLORS.safe,    bg: `${COLORS.safe}15`,    icon: 'shield-checkmark', label: 'Safe'    },
  caution: { color: COLORS.caution, bg: `${COLORS.caution}15`, icon: 'warning',          label: 'Caution' },
  high:    { color: COLORS.danger,  bg: `${COLORS.danger}15`,  icon: 'close-circle',     label: 'Avoid'   },
};

export default function SafetyScreen() {
  const router = useRouter();

  const { data, isLoading, refetch, isRefetching } = useQuery({
    queryKey: ['safety-zones'],
    queryFn:  () => safetyApi.zones().then(r => r.data),
    staleTime: 1000 * 60 * 10,
  });

  const zones: any[] = data?.zones || [];
  const counts = {
    safe:    zones.filter(z => z.zone_type === 'safe').length,
    caution: zones.filter(z => z.zone_type === 'caution').length,
    high:    zones.filter(z => z.zone_type === 'high').length,
  };

  return (
    <View style={styles.container}>
      <SafeAreaView edges={['top']} style={styles.headerWrap}>
        <View style={styles.header}>
          <Ionicons name="shield-checkmark" size={22} color={COLORS.teal} />
          <Text style={styles.headerTitle}>Safety</Text>
        </View>
        <Text style={styles.headerSub}>Kingston transport zone ratings · ML Model 6</Text>
      </SafeAreaView>

      <ScrollView showsVerticalScrollIndicator={false} refreshing={isRefetching} onRefresh={refetch}>

        {/* SOS button — always prominent */}
        <TouchableOpacity
          style={styles.sosBtn}
          onPress={() => router.push('/safety/sos')}
          activeOpacity={0.85}
        >
          <View style={styles.sosBtnInner}>
            <Ionicons name="warning" size={24} color="#fff" />
            <View>
              <Text style={styles.sosBtnTitle}>Emergency SOS</Text>
              <Text style={styles.sosBtnSub}>Tap to send GPS to emergency contact</Text>
            </View>
          </View>
          <Ionicons name="chevron-forward" size={18} color="rgba(255,255,255,0.6)" />
        </TouchableOpacity>

        {/* Zone summary */}
        <View style={styles.section}>
          <View style={styles.summaryRow}>
            {Object.entries(counts).map(([type, count]) => {
              const cfg = ZONE_CFG[type as keyof typeof ZONE_CFG];
              return (
                <View key={type} style={[styles.summaryCard, { backgroundColor: cfg.bg }]}>
                  <Ionicons name={cfg.icon as any} size={20} color={cfg.color} />
                  <Text style={[styles.summaryCount, { color: cfg.color }]}>{count}</Text>
                  <Text style={[styles.summaryLabel, { color: cfg.color }]}>{cfg.label}</Text>
                </View>
              );
            })}
          </View>
        </View>

        {/* Guide */}
        <View style={styles.section}>
          <View style={styles.guideCard}>
            <Text style={styles.guideTitle}>Zone Guide</Text>
            {[
              { type: 'safe',    desc: 'Well-lit, high traffic, security present' },
              { type: 'caution', desc: 'Extra vigilance advised, especially at night' },
              { type: 'high',    desc: 'Not recommended — use alternative routes' },
            ].map((g, i) => {
              const cfg = ZONE_CFG[g.type as keyof typeof ZONE_CFG];
              return (
                <View key={i} style={styles.guideRow}>
                  <View style={[styles.guideDot, { backgroundColor: cfg.color }]} />
                  <View>
                    <Text style={[styles.guideType, { color: cfg.color }]}>{cfg.label}</Text>
                    <Text style={styles.guideDesc}>{g.desc}</Text>
                  </View>
                </View>
              );
            })}
            <Text style={styles.mlNote}>Safety scores powered by ML Model 6 · Updates with route data</Text>
          </View>
        </View>

        {/* Call 119 */}
        <View style={styles.section}>
          <TouchableOpacity style={styles.callCard} onPress={() => Linking.openURL('tel:119')} activeOpacity={0.85}>
            <Ionicons name="call" size={20} color="#fff" />
            <View style={{ flex: 1 }}>
              <Text style={styles.callTitle}>Call 119</Text>
              <Text style={styles.callSub}>Jamaica Constabulary Force</Text>
            </View>
            <Ionicons name="chevron-forward" size={16} color="rgba(255,255,255,0.5)" />
          </TouchableOpacity>
        </View>

        {/* Zone list */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>All Zones ({zones.length})</Text>
          {isLoading ? (
            <ActivityIndicator color={COLORS.teal} style={{ marginTop: 20 }} />
          ) : zones.map((z: any, i: number) => {
            const cfg = ZONE_CFG[z.zone_type as keyof typeof ZONE_CFG] || ZONE_CFG.caution;
            return (
              <View key={i} style={[styles.zoneCard, { borderLeftColor: cfg.color }]}>
                <View style={[styles.zoneIcon, { backgroundColor: cfg.bg }]}>
                  <Ionicons name={cfg.icon as any} size={18} color={cfg.color} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.zoneName}>{z.name}</Text>
                  {z.description && <Text style={styles.zoneDesc}>{z.description}</Text>}
                  {z.safety_score && (
                    <Text style={[styles.zoneScore, { color: cfg.color }]}>
                      ML Safety Score: {z.safety_score}/100
                    </Text>
                  )}
                </View>
                <View style={[styles.zoneBadge, { backgroundColor: cfg.bg }]}>
                  <Text style={[styles.zoneBadgeText, { color: cfg.color }]}>{cfg.label}</Text>
                </View>
              </View>
            );
          })}
        </View>

        <View style={{ height: 24 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container:       { flex: 1, backgroundColor: COLORS.background },
  headerWrap:      { backgroundColor: COLORS.navy },
  header:          { flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 20, paddingTop: 10, paddingBottom: 4 },
  headerTitle:     { fontSize: 22, fontWeight: '800', color: COLORS.text },
  headerSub:       { fontSize: 12, color: COLORS.teal, paddingHorizontal: 20, paddingBottom: 14 },

  sosBtn:          { margin: 16, backgroundColor: COLORS.sos, borderRadius: 16, padding: 18, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  sosBtnInner:     { flexDirection: 'row', alignItems: 'center', gap: 14 },
  sosBtnTitle:     { fontSize: 17, fontWeight: '800', color: '#fff' },
  sosBtnSub:       { fontSize: 12, color: 'rgba(255,255,255,0.7)', marginTop: 2 },

  section:         { paddingHorizontal: 16, marginBottom: 20 },
  sectionTitle:    { fontSize: 17, fontWeight: '700', color: COLORS.text, marginBottom: 12 },

  summaryRow:      { flexDirection: 'row', gap: 10 },
  summaryCard:     { flex: 1, borderRadius: 14, padding: 14, alignItems: 'center', gap: 4 },
  summaryCount:    { fontSize: 22, fontWeight: '800' },
  summaryLabel:    { fontSize: 11, fontWeight: '600' },

  guideCard:       { backgroundColor: COLORS.surface, borderRadius: 16, padding: 16, borderWidth: 1, borderColor: COLORS.border },
  guideTitle:      { fontSize: 15, fontWeight: '700', color: COLORS.text, marginBottom: 12 },
  guideRow:        { flexDirection: 'row', gap: 10, alignItems: 'flex-start', marginBottom: 10 },
  guideDot:        { width: 10, height: 10, borderRadius: 5, marginTop: 4 },
  guideType:       { fontSize: 13, fontWeight: '700' },
  guideDesc:       { fontSize: 12, color: COLORS.textSec, marginTop: 2 },
  mlNote:          { fontSize: 11, color: COLORS.muted, marginTop: 8, fontStyle: 'italic' },

  callCard:        { backgroundColor: '#7F1D1D', borderRadius: 14, padding: 16, flexDirection: 'row', alignItems: 'center', gap: 12 },
  callTitle:       { fontSize: 15, fontWeight: '700', color: '#fff' },
  callSub:         { fontSize: 12, color: 'rgba(255,255,255,0.7)', marginTop: 2 },

  zoneCard:        { backgroundColor: COLORS.surface, borderRadius: 12, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 8, borderLeftWidth: 4, borderWidth: 1, borderColor: COLORS.border },
  zoneIcon:        { width: 38, height: 38, borderRadius: 10, justifyContent: 'center', alignItems: 'center' },
  zoneName:        { fontSize: 14, fontWeight: '700', color: COLORS.text },
  zoneDesc:        { fontSize: 12, color: COLORS.textSec, marginTop: 2, lineHeight: 16 },
  zoneScore:       { fontSize: 11, fontWeight: '600', marginTop: 4 },
  zoneBadge:       { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 10 },
  zoneBadgeText:   { fontSize: 10, fontWeight: '700' },
});
