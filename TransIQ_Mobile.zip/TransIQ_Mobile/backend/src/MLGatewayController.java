package com.transiq.api.controller;

import com.transiq.api.dto.PredictRequest;
import com.transiq.api.dto.PredictResponse;
import com.transiq.api.service.MLGatewayService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;

/**
 * ML Prediction Gateway — POST /api/predict
 *
 * Single endpoint for all 6 ML model predictions.
 * Spring Boot enriches the request with traffic, weather, and route data
 * before forwarding to the appropriate AWS Lambda function.
 *
 * X-Mock: true header → returns synthetic data (MLGatewayService.getMockResponse).
 * Used during pre-hackathon development until Ayanna's Lambda functions are live.
 *
 * Schema is frozen as of March 12. No changes after that date.
 * Coordinate Lambda ARN updates with Ayanna and the DevOps pipeline.
 */
@RestController
@RequestMapping("/api")
public class MLGatewayController {

    private final MLGatewayService mlGatewayService;

    public MLGatewayController(MLGatewayService mlGatewayService) {
        this.mlGatewayService = mlGatewayService;
    }

    /**
     * POST /api/predict
     *
     * Request body (from mobile app):
     *   { origin, destination, departTime, budgetJmd? }
     *
     * Spring Boot adds before forwarding to Lambda:
     *   routeIds, trafficLevel (Google Maps), weatherCode (Met Service),
     *   dayOfWeek, timeOfDay
     *
     * Response contains all 6 model outputs:
     *   eta, fare, traffic, departure, reliability, safety
     */
    @PostMapping("/predict")
    public ResponseEntity<PredictResponse> predict(
            @Valid @RequestBody PredictRequest request,
            @RequestHeader(value = "X-Mock", defaultValue = "false") boolean isMock
    ) {
        PredictResponse response = isMock
            ? mlGatewayService.getMockResponse(request)
            : mlGatewayService.predict(request);

        return ResponseEntity.ok(response);
    }
}
