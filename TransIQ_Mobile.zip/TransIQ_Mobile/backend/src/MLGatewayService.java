package com.transiq.api.service;

import com.transiq.api.dto.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.services.lambda.LambdaClient;
import software.amazon.awssdk.services.lambda.model.InvokeRequest;
import software.amazon.awssdk.core.SdkBytes;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.*;
import java.util.*;

/**
 * MLGatewayService
 *
 * Handles all communication with Ayanna's ML Lambda functions.
 *
 * Flow:
 *   1. Enrich PredictRequest with data from PostgreSQL (route IDs),
 *      Google Maps API (traffic level), Met Service (weather code),
 *      and time derivations (day of week, time of day bucket).
 *   2. Invoke each Lambda function in parallel.
 *   3. Assemble the PredictResponse.
 *
 * Mock mode (X-Mock: true):
 *   Returns synthetic predictions without calling Lambda.
 *   Used during pre-hackathon development.
 *   Remove X-Mock header from frontend when Ayanna deploys Lambda on hackathon day.
 *
 * Lambda ARNs are configured in application.yml.
 * Ayanna updates these after deploying on hackathon day.
 */
@Service
public class MLGatewayService {

    @Value("${ml.lambda.eta-arn}")        private String etaArn;
    @Value("${ml.lambda.fare-arn}")       private String fareArn;
    @Value("${ml.lambda.traffic-arn}")    private String trafficArn;
    @Value("${ml.lambda.departure-arn}")  private String departureArn;
    @Value("${ml.lambda.reliability-arn}")private String reliabilityArn;
    @Value("${ml.lambda.safety-arn}")     private String safetyArn;

    private final LambdaClient      lambdaClient;
    private final ObjectMapper      mapper;
    private final RouteDataService  routeDataService;
    private final TrafficService    trafficService;
    private final WeatherService    weatherService;

    public MLGatewayService(
        LambdaClient lambdaClient, ObjectMapper mapper,
        RouteDataService routeDataService,
        TrafficService trafficService,
        WeatherService weatherService
    ) {
        this.lambdaClient    = lambdaClient;
        this.mapper          = mapper;
        this.routeDataService = routeDataService;
        this.trafficService  = trafficService;
        this.weatherService  = weatherService;
    }

    /**
     * Live prediction — calls AWS Lambda functions.
     * Each model is a separate Lambda invocation.
     * Runs in parallel via CompletableFuture (not shown for brevity).
     */
    public PredictResponse predict(PredictRequest request) {
        // 1. Enrich request
        EnrichedPredictRequest enriched = enrich(request);

        // 2. Invoke all 6 Lambda functions
        ETAPrediction        eta         = invokeEta(enriched);
        FarePrediction       fare        = invokeFare(enriched);
        TrafficPrediction    traffic     = invokeTraffic(enriched);
        DeparturePrediction  departure   = invokeDeparture(enriched);
        ReliabilityPrediction reliability = invokeReliability(enriched);
        SafetyPrediction     safety      = invokeSafety(enriched);

        // 3. Assemble response
        return PredictResponse.builder()
            .eta(eta).fare(fare).traffic(traffic)
            .departure(departure).reliability(reliability).safety(safety)
            .isMock(false)
            .build();
    }

    /**
     * Mock response — returned when X-Mock: true header is present.
     * Values match the contracts defined in the project scope Section 3.3.
     * These are the synthetic defaults Ayanna's models must beat.
     */
    public PredictResponse getMockResponse(PredictRequest request) {
        return PredictResponse.builder()
            .eta(new ETAPrediction(30, 0.87))
            .fare(new FarePrediction(200.0, 0.91))
            .traffic(new TrafficPrediction(4.0, "moderate"))
            .departure(new DeparturePrediction(
                request.getDepartTime().plusMinutes(10), 15
            ))
            .reliability(new ReliabilityPrediction(75, "B"))
            .safety(new SafetyPrediction(80, "low"))
            .isMock(true)
            .build();
    }

    // ── Enrichment ─────────────────────────────────────────────────────────────
    private EnrichedPredictRequest enrich(PredictRequest req) {
        List<String> routeIds    = routeDataService.getRouteIds(req.getOrigin(), req.getDestination());
        double       traffic     = trafficService.getCurrentLevel(req.getOrigin(), req.getDestination());
        String       weather     = weatherService.getCurrentCode();
        ZonedDateTime dt         = req.getDepartTime().atZone(ZoneId.of("America/Jamaica"));
        int          dayOfWeek   = dt.getDayOfWeek().getValue() % 7; // 0=Sun
        String       timeOfDay   = getTimeOfDayBucket(dt.getHour());

        return EnrichedPredictRequest.from(req)
            .routeIds(routeIds)
            .trafficLevel(traffic)
            .weatherCode(weather)
            .dayOfWeek(dayOfWeek)
            .timeOfDay(timeOfDay)
            .build();
    }

    private String getTimeOfDayBucket(int hour) {
        if (hour >= 5  && hour < 12) return "morning";
        if (hour >= 12 && hour < 17) return "midday";
        if (hour >= 17 && hour < 21) return "evening";
        return "night";
    }

    // ── Lambda invocation helpers ──────────────────────────────────────────────
    private <T> T invokeLambda(String arn, Object payload, Class<T> responseClass) {
        try {
            String json = mapper.writeValueAsString(payload);
            InvokeRequest req = InvokeRequest.builder()
                .functionName(arn)
                .payload(SdkBytes.fromUtf8String(json))
                .build();
            String responseJson = lambdaClient.invoke(req).payload().asUtf8String();
            return mapper.readValue(responseJson, responseClass);
        } catch (Exception e) {
            throw new MLGatewayException("Lambda invocation failed for " + arn, e);
        }
    }

    private ETAPrediction        invokeEta(EnrichedPredictRequest r)         { return invokeLambda(etaArn,         r, ETAPrediction.class);         }
    private FarePrediction       invokeFare(EnrichedPredictRequest r)        { return invokeLambda(fareArn,        r, FarePrediction.class);        }
    private TrafficPrediction    invokeTraffic(EnrichedPredictRequest r)     { return invokeLambda(trafficArn,     r, TrafficPrediction.class);     }
    private DeparturePrediction  invokeDeparture(EnrichedPredictRequest r)   { return invokeLambda(departureArn,   r, DeparturePrediction.class);   }
    private ReliabilityPrediction invokeReliability(EnrichedPredictRequest r){ return invokeLambda(reliabilityArn, r, ReliabilityPrediction.class); }
    private SafetyPrediction     invokeSafety(EnrichedPredictRequest r)      { return invokeLambda(safetyArn,      r, SafetyPrediction.class);      }
}
