package com.transiq.api.kafka;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.transiq.api.service.NotificationService;
import com.transiq.api.service.WebSocketService;
import com.transiq.api.service.MLGatewayService;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

/**
 * TransIQ Kafka Consumer
 *
 * Consumes ML event streams and forwards them to:
 *   - WebSocket → React Native app (live ETA update)
 *   - Push Notification → user device (safety alert)
 *
 * Topics:
 *   ml-traffic-updates — published by traffic-congestion-fn Lambda (Model 3)
 *                        when congestion changes significantly during a journey.
 *                        Consumer re-calls ETA Lambda (Model 1) and pushes update
 *                        to the active journey via WebSocket.
 *
 *   ml-safety-alerts   — published by safety-score-fn Lambda (Model 6)
 *                        when a route's safety score drops below threshold.
 *                        Consumer sends push notification and triggers SOS prompt.
 *
 *   traffic-events     — published by Google Maps API poller (Jodel's scraper).
 *                        Used to enrich ML prediction requests.
 *
 *   route-updates      — published by TA/JUTC scrapers every 15 minutes.
 *                        Consumer updates PostgreSQL route cache.
 */
@Component
public class TransIQKafkaConsumer {

    private static final Logger log = LoggerFactory.getLogger(TransIQKafkaConsumer.class);

    private final ObjectMapper       mapper;
    private final WebSocketService   webSocketService;
    private final NotificationService notificationService;
    private final MLGatewayService   mlGatewayService;

    public TransIQKafkaConsumer(
        ObjectMapper mapper,
        WebSocketService webSocketService,
        NotificationService notificationService,
        MLGatewayService mlGatewayService
    ) {
        this.mapper              = mapper;
        this.webSocketService    = webSocketService;
        this.notificationService = notificationService;
        this.mlGatewayService    = mlGatewayService;
    }

    /**
     * ML traffic update → live ETA recalculation.
     * This is the "wow moment" in the hackathon demo:
     *   trigger a Kafka event → watch ETA change on screen in real time.
     */
    @KafkaListener(topics = "${kafka.topics.ml-traffic-updates}", groupId = "transiq-backend")
    public void onMLTrafficUpdate(ConsumerRecord<String, String> record) {
        try {
            var event = mapper.readValue(record.value(), MLTrafficUpdateEvent.class);
            log.info("ML traffic update: journeyId={} congestion={}", event.getJourneyId(), event.getCongestionScore());

            // Re-invoke ETA Lambda with updated traffic level
            var updatedEta = mlGatewayService.recalculateEta(event.getJourneyId(), event.getCongestionScore());

            // Push updated ETA to mobile app via WebSocket
            webSocketService.sendEtaUpdate(event.getJourneyId(), updatedEta);

        } catch (Exception e) {
            log.error("Failed to process ml-traffic-updates: {}", e.getMessage());
        }
    }

    /**
     * ML safety alert → push notification + SOS prompt.
     * Fires when Model 6 detects a route's safety score drops below 50.
     */
    @KafkaListener(topics = "${kafka.topics.ml-safety-alerts}", groupId = "transiq-backend")
    public void onMLSafetyAlert(ConsumerRecord<String, String> record) {
        try {
            var alert = mapper.readValue(record.value(), MLSafetyAlertEvent.class);
            log.warn("ML safety alert: userId={} safetyScore={} riskLevel={}", alert.getUserId(), alert.getSafetyScore(), alert.getRiskLevel());

            notificationService.sendSafetyAlert(alert.getUserId(), alert.getSafetyScore(), alert.getRiskLevel(), alert.getJourneyId());

        } catch (Exception e) {
            log.error("Failed to process ml-safety-alerts: {}", e.getMessage());
        }
    }

    /**
     * Google Maps traffic event → update PostgreSQL traffic cache.
     * Used by MLGatewayService.enrich() to get current traffic level.
     */
    @KafkaListener(topics = "${kafka.topics.traffic-events}", groupId = "transiq-backend")
    public void onTrafficEvent(ConsumerRecord<String, String> record) {
        try {
            log.debug("Traffic event received: {}", record.value().substring(0, Math.min(80, record.value().length())));
            // Store in Redis cache for fast lookup by MLGatewayService
        } catch (Exception e) {
            log.error("Failed to process traffic-events: {}", e.getMessage());
        }
    }

    /**
     * Scraper route update → refresh PostgreSQL route cache.
     * Published by Jodel's Python scraper every 15 minutes.
     */
    @KafkaListener(topics = "${kafka.topics.route-updates}", groupId = "transiq-backend")
    public void onRouteUpdate(ConsumerRecord<String, String> record) {
        try {
            log.info("Route update received from scraper");
            // Invalidate route cache in Redis
        } catch (Exception e) {
            log.error("Failed to process route-updates: {}", e.getMessage());
        }
    }

    // ── Event DTOs ─────────────────────────────────────────────────────────────
    record MLTrafficUpdateEvent(String journeyId, double congestionScore, String label) {}
    record MLSafetyAlertEvent(String userId, String journeyId, double safetyScore, String riskLevel) {}
}
