// Expo environment variable types
// All EXPO_PUBLIC_* variables are available in the app bundle

declare module '@env' {
  export const EXPO_PUBLIC_API_URL: string;
}
