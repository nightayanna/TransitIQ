"""
TransIQ Data Scraper
────────────────────────────────────────────────────────────────────────────────
Scrapes all Jamaican public transport data sources and loads into PostgreSQL.
Publishes route-updates events to Kafka on every successful scrape run.

Sources:
  ta.org.jm/available-routes   — Route Taxi routes (all hubs)
  ta.org.jm/routes-and-fares   — Route Taxi regulated fares
  jutc.com.jm                  — JUTC bus schedules, stops, fares
  Uber API                     — Live fare estimates (via backend proxy)

Schedule: Every 15 minutes via APScheduler.
Falls back to synthetic data (data/synthetic-fallback.json) if any scraper fails.
Kafka topic: route-updates (consumed by Spring Boot backend)
"""

import asyncio
import logging
import json
from datetime import datetime
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.interval import IntervalTrigger

from scrapers.ta_routes_scraper   import TAROutesScraper
from scrapers.ta_fares_scraper    import TAFaresScraper
from scrapers.jutc_scraper        import JUTCScraper
from storage.database             import DatabaseStorage
from kafka_publisher              import KafkaPublisher
from config                       import settings

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
log = logging.getLogger("transiq.scraper")


async def run_scrape_cycle():
    """
    Full scrape cycle — runs every 15 minutes.
    Scrapes all sources, upserts into PostgreSQL, publishes Kafka event.
    Falls back to synthetic data on any failure.
    """
    run_id  = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    results = {}

    log.info(f"[{run_id}] Starting 15-minute scrape cycle")

    db        = DatabaseStorage(settings.DATABASE_URL)
    kafka     = KafkaPublisher(settings.KAFKA_BROKERS, topic="route-updates")
    scrapers  = [TAROutesScraper(), TAFaresScraper(), JUTCScraper()]

    for scraper in scrapers:
        try:
            data   = await scraper.scrape()
            upserted = await db.upsert(scraper.data_type, data)
            results[scraper.source_name] = {
                "status":   "ok",
                "records":  len(data),
                "upserted": upserted,
            }
            log.info(f"[{run_id}] {scraper.source_name}: {len(data)} records scraped, {upserted} upserted")
        except Exception as e:
            log.error(f"[{run_id}] {scraper.source_name} failed: {e}")
            results[scraper.source_name] = {"status": "error", "error": str(e)}
            await _load_fallback(db, scraper.source_name)

    # Publish route-updates event to Kafka → Spring Boot invalidates Redis cache
    await kafka.publish({
        "runId":     run_id,
        "timestamp": datetime.utcnow().isoformat(),
        "results":   results,
    })

    log.info(f"[{run_id}] Scrape cycle complete. Results: {json.dumps(results)}")
    return results


async def _load_fallback(db: DatabaseStorage, source: str):
    """Load synthetic fallback data when a scraper fails."""
    fallback_path = f"data/synthetic-fallback.json"
    try:
        with open(fallback_path) as f:
            fallback = json.load(f)
        source_data = fallback.get(source, [])
        if source_data:
            await db.upsert(source, source_data)
            log.info(f"Loaded {len(source_data)} fallback records for {source}")
    except Exception as e:
        log.error(f"Fallback load failed for {source}: {e}")


async def main():
    log.info("TransIQ Scraper starting — 15-minute refresh cycle")

    # Run immediately on startup
    await run_scrape_cycle()

    # Schedule every 15 minutes
    scheduler = AsyncIOScheduler()
    scheduler.add_job(
        run_scrape_cycle,
        trigger=IntervalTrigger(minutes=15),
        id="transiq_scrape",
        replace_existing=True,
        max_instances=1,
    )
    scheduler.start()

    log.info("Scheduler running — next scrape in 15 minutes")

    # Keep running
    try:
        await asyncio.Event().wait()
    except (KeyboardInterrupt, SystemExit):
        scheduler.shutdown()
        log.info("Scraper stopped")


if __name__ == "__main__":
    asyncio.run(main())
