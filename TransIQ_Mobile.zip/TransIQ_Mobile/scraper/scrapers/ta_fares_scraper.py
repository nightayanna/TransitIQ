"""
TA Fares Scraper
─────────────────────────────────────────────────────────────────────────────
Scrapes ta.org.jm/routes-and-fares for OUR-regulated route taxi fares.

Extracts:
  - Route ID
  - Origin → Destination
  - Base fare (JMD)
  - Regulated: True (all TA fares are government-regulated)
"""

import logging
from .base_scraper import BaseScraper

log = logging.getLogger(__name__)

TA_FARES_URL = "https://www.ta.org.jm/routes-and-fares"


class TAFaresScraper(BaseScraper):
    source_name = "ta_fares"
    data_type   = "fares"

    async def scrape(self) -> list[dict]:
        fares = []
        try:
            resp = await self.get(TA_FARES_URL)
            soup = self.parse_html(resp.text)

            rows = soup.select("table tr, .fare-row")

            for row in rows:
                cells = row.find_all(["td", "th"])
                if len(cells) < 3:
                    continue

                route     = cells[0].get_text(strip=True)
                origin    = cells[1].get_text(strip=True) if len(cells) > 1 else ""
                destination=cells[2].get_text(strip=True) if len(cells) > 2 else ""
                fare_text = cells[3].get_text(strip=True) if len(cells) > 3 else ""

                # Parse fare amount — strip JMD prefix and commas
                fare_jmd = None
                import re
                match = re.search(r'[\d,]+(?:\.\d{2})?', fare_text.replace(',', ''))
                if match:
                    try:
                        fare_jmd = float(match.group().replace(',', ''))
                    except ValueError:
                        pass

                if not route or fare_jmd is None:
                    continue

                fares.append({
                    "source":       "ta_fares",
                    "operator":     "Route Taxi",
                    "route":        route,
                    "origin":       origin,
                    "destination":  destination,
                    "fare_type":    "Standard",
                    "amount_jmd":   fare_jmd,
                    "currency":     "JMD",
                    "regulated":    True,
                    "regulator":    "OUR",
                    "is_current":   True,
                })

            log.info(f"TAFaresScraper: found {len(fares)} fares")

        except Exception as e:
            log.error(f"TAFaresScraper failed: {e}")
            raise

        return fares
