"""
TA Routes Scraper
─────────────────────────────────────────────────────────────────────────────
Scrapes ta.org.jm/available-routes for all licensed route taxi routes.

Extracts:
  - Route ID
  - Route name
  - Origin hub
  - Destination hub
  - Operator type (route taxi)
"""

import logging
import re
from .base_scraper import BaseScraper

log = logging.getLogger(__name__)

TA_BASE   = "https://www.ta.org.jm"
ROUTES_URL = f"{TA_BASE}/available-routes"


class TAROutesScraper(BaseScraper):
    source_name = "ta_routes"
    data_type   = "routes"

    async def scrape(self) -> list[dict]:
        routes = []
        try:
            resp = await self.get(ROUTES_URL)
            soup = self.parse_html(resp.text)

            # TA site structure — adapt selectors to live page
            rows = soup.select("table tr, .route-row, .route-item")

            for row in rows:
                cells = row.find_all(["td", "th"])
                if len(cells) < 3:
                    continue

                route_id   = cells[0].get_text(strip=True)
                route_name = cells[1].get_text(strip=True) if len(cells) > 1 else ""
                origin     = cells[2].get_text(strip=True) if len(cells) > 2 else ""
                destination= cells[3].get_text(strip=True) if len(cells) > 3 else ""

                if not route_id or not origin:
                    continue

                routes.append({
                    "source":          "ta_routes",
                    "route_number":    route_id,
                    "route_name":      route_name or f"{origin} → {destination}",
                    "origin":          origin,
                    "destination":     destination,
                    "operator":        "Route Taxi",
                    "transport_type":  "taxi",
                    "is_active":       True,
                })

            log.info(f"TAROutesScraper: found {len(routes)} routes")

        except Exception as e:
            log.error(f"TAROutesScraper failed: {e}")
            raise

        return routes
