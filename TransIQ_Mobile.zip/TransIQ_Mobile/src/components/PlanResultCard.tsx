import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { COLORS } from '../utils/theme';
import { PlanCard } from '../types/ml';

interface Props {
  plan:         PlanCard;
  index:        number;
  onViewDetail: (id: string) => void;
}

const PLAN_CONFIG = {
  fastest:  { color: COLORS.fastest,  icon: 'flash',     label: 'Fastest'  },
  cheapest: { color: COLORS.cheapest, icon: 'cash',      label: 'Cheapest' },
  balanced: { color: COLORS.balanced, icon: 'git-merge', label: 'Balanced' },
};

const LEG_COLORS: Record<string, string> = {
  bus:     COLORS.bus,
  taxi:    COLORS.taxi,
  express: COLORS.express,
  juta:    COLORS.juta,
  uber:    COLORS.uber,
  walk:    COLORS.muted,
};

const LEG_ICONS: Record<string, string> = {
  bus: 'bus', taxi: 'taxi', express: 'bus-coach', juta: 'leaf', uber: 'car', walk: 'walk',
};

const CONGESTION_COLOR = { clear: COLORS.safe, moderate: COLORS.gold, heavy: COLORS.danger };
const RISK_COLOR       = { low: COLORS.safe,   moderate: COLORS.gold, high: COLORS.danger };

export default function PlanResultCard({ plan, index, onViewDetail }: Props) {
  const [expanded, setExpanded] = useState(index === 0);
  const cfg = PLAN_CONFIG[plan.planType] || PLAN_CONFIG.balanced;

  const confidence = Math.round((plan.ml.eta.confidence + plan.ml.fare.confidence) / 2 * 100);

  return (
    <View style={[styles.card, index === 0 && { borderColor: cfg.color, borderWidth: 2 }]}>
      {/* Header */}
      <TouchableOpacity style={styles.header} onPress={() => setExpanded(e => !e)} activeOpacity={0.8}>
        <View style={styles.titleRow}>
          <View style={[styles.planBadge, { backgroundColor: `${cfg.color}20`, borderColor: cfg.color }]}>
            <Ionicons name={cfg.icon as any} size={14} color={cfg.color} />
            <Text style={[styles.planBadgeText, { color: cfg.color }]}>{cfg.label}</Text>
          </View>
          {index === 0 && <View style={styles.bestBadge}><Text style={styles.bestText}>Recommended</Text></View>}
          {plan.ml.isMock && (
            <View style={styles.mockBadge}>
              <Text style={styles.mockText}>MOCK</Text>
            </View>
          )}
        </View>

        {/* Key metrics */}
        <View style={styles.metricsRow}>
          <View style={styles.metric}>
            <Ionicons name="time-outline" size={14} color={COLORS.textSec} />
            <Text style={styles.metricValue}>{plan.etaMinutes} min</Text>
          </View>
          <View style={styles.metricDot} />
          <View style={styles.metric}>
            <Ionicons name="cash-outline" size={14} color={COLORS.textSec} />
            <Text style={styles.metricValue}>JMD {plan.fareJmd.toLocaleString()}</Text>
          </View>
          <View style={styles.metricDot} />
          <View style={styles.metric}>
            <Ionicons name="git-merge-outline" size={14} color={COLORS.textSec} />
            <Text style={styles.metricValue}>{plan.transfers} transfer{plan.transfers !== 1 ? 's' : ''}</Text>
          </View>
        </View>

        {/* ML score row */}
        <View style={styles.mlRow}>
          {/* Safety score (Model 6) */}
          <View style={[styles.mlScore, { backgroundColor: `${RISK_COLOR[plan.ml.safety.riskLevel]}15` }]}>
            <Ionicons name="shield-checkmark" size={12} color={RISK_COLOR[plan.ml.safety.riskLevel]} />
            <Text style={[styles.mlScoreText, { color: RISK_COLOR[plan.ml.safety.riskLevel] }]}>
              Safety {plan.ml.safety.safetyScore}
            </Text>
          </View>
          {/* Reliability (Model 5) */}
          <View style={[styles.mlScore, { backgroundColor: `${COLORS.teal}15` }]}>
            <MaterialCommunityIcons name="star-circle" size={12} color={COLORS.teal} />
            <Text style={[styles.mlScoreText, { color: COLORS.teal }]}>
              Grade {plan.ml.reliability.grade}
            </Text>
          </View>
          {/* Traffic (Model 3) */}
          <View style={[styles.mlScore, { backgroundColor: `${CONGESTION_COLOR[plan.ml.traffic.label]}15` }]}>
            <Ionicons name="car-outline" size={12} color={CONGESTION_COLOR[plan.ml.traffic.label]} />
            <Text style={[styles.mlScoreText, { color: CONGESTION_COLOR[plan.ml.traffic.label] }]}>
              {plan.ml.traffic.label}
            </Text>
          </View>
          {/* Confidence */}
          <Text style={styles.confidenceText}>{confidence}% confident</Text>

          <Ionicons name={expanded ? 'chevron-up' : 'chevron-down'} size={16} color={COLORS.muted} style={{ marginLeft: 'auto' }} />
        </View>
      </TouchableOpacity>

      {/* Best departure time (Model 4) */}
      {expanded && (
        <View style={styles.departureBar}>
          <Ionicons name="alarm-outline" size={14} color={COLORS.gold} />
          <Text style={styles.departureText}>
            Best departure: {new Date(plan.ml.departure.bestDepart).toLocaleTimeString('en-JM', { hour: '2-digit', minute: '2-digit' })}
            {' '}(±{plan.ml.departure.windowMinutes}min window)
          </Text>
        </View>
      )}

      {/* Journey legs */}
      {expanded && (
        <View style={styles.legs}>
          <View style={styles.legsDivider} />
          {plan.legs.map((leg, i) => {
            const legColor = LEG_COLORS[leg.type] || COLORS.muted;
            const legIcon  = LEG_ICONS[leg.type]  || 'bus';
            return (
              <View key={i} style={styles.legRow}>
                <View style={styles.legTimeline}>
                  <View style={[styles.legDot, { backgroundColor: legColor }]}>
                    <MaterialCommunityIcons name={legIcon as any} size={11} color="#fff" />
                  </View>
                  {i < plan.legs.length - 1 && <View style={[styles.legLine, { backgroundColor: legColor }]} />}
                </View>
                <View style={styles.legContent}>
                  <Text style={styles.legInstruction}>{leg.instruction}</Text>
                  <View style={styles.legMeta}>
                    {leg.routeNumber && (
                      <View style={[styles.routeTag, { backgroundColor: `${legColor}20` }]}>
                        <Text style={[styles.routeTagText, { color: legColor }]}>{leg.routeNumber}</Text>
                      </View>
                    )}
                    <Text style={styles.legMetaText}>{leg.durationMins}min{leg.fareJmd > 0 ? ` · JMD ${leg.fareJmd}` : ''}</Text>
                    {leg.congestion && (
                      <View style={[styles.congestionTag, { backgroundColor: `${CONGESTION_COLOR[leg.congestion]}15` }]}>
                        <Text style={[styles.congestionText, { color: CONGESTION_COLOR[leg.congestion] }]}>{leg.congestion}</Text>
                      </View>
                    )}
                  </View>
                </View>
              </View>
            );
          })}

          <TouchableOpacity style={styles.viewDetailBtn} onPress={() => onViewDetail(plan.id)} activeOpacity={0.8}>
            <Text style={styles.viewDetailText}>View full journey details</Text>
            <Ionicons name="chevron-forward" size={14} color={COLORS.teal} />
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  card:            { backgroundColor: COLORS.surface, borderRadius: 16, marginBottom: 12, overflow: 'hidden', borderWidth: 1, borderColor: COLORS.border },
  header:          { padding: 16 },
  titleRow:        { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 10 },
  planBadge:       { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20, borderWidth: 1 },
  planBadgeText:   { fontSize: 13, fontWeight: '700' },
  bestBadge:       { backgroundColor: `${COLORS.gold}20`, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 20, borderWidth: 1, borderColor: `${COLORS.gold}40` },
  bestText:        { fontSize: 11, color: COLORS.gold, fontWeight: '700' },
  mockBadge:       { backgroundColor: `${COLORS.muted}20`, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 20 },
  mockText:        { fontSize: 9, color: COLORS.muted, fontWeight: '700', letterSpacing: 1 },

  metricsRow:      { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 10 },
  metric:          { flexDirection: 'row', alignItems: 'center', gap: 4 },
  metricValue:     { fontSize: 13, color: COLORS.text, fontWeight: '600' },
  metricDot:       { width: 3, height: 3, borderRadius: 1.5, backgroundColor: COLORS.border },

  mlRow:           { flexDirection: 'row', alignItems: 'center', gap: 6, flexWrap: 'wrap' },
  mlScore:         { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 8, paddingVertical: 4, borderRadius: 20 },
  mlScoreText:     { fontSize: 11, fontWeight: '600' },
  confidenceText:  { fontSize: 11, color: COLORS.muted },

  departureBar:    { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: `${COLORS.gold}10`, paddingHorizontal: 16, paddingVertical: 10, borderTopWidth: 1, borderTopColor: COLORS.border },
  departureText:   { fontSize: 12, color: COLORS.gold, fontWeight: '500' },

  legsDivider:     { height: 1, backgroundColor: COLORS.border, marginBottom: 14 },
  legs:            { paddingHorizontal: 16, paddingBottom: 14 },
  legRow:          { flexDirection: 'row', gap: 12, marginBottom: 14 },
  legTimeline:     { width: 28, alignItems: 'center' },
  legDot:          { width: 28, height: 28, borderRadius: 14, justifyContent: 'center', alignItems: 'center' },
  legLine:         { width: 2, flex: 1, minHeight: 16, marginTop: 4, opacity: 0.3 },
  legContent:      { flex: 1, paddingTop: 4 },
  legInstruction:  { fontSize: 13, fontWeight: '600', color: COLORS.text, lineHeight: 18 },
  legMeta:         { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 5 },
  routeTag:        { paddingHorizontal: 8, paddingVertical: 2, borderRadius: 8 },
  routeTagText:    { fontSize: 11, fontWeight: '700' },
  legMetaText:     { fontSize: 11, color: COLORS.muted },
  congestionTag:   { paddingHorizontal: 7, paddingVertical: 2, borderRadius: 8 },
  congestionText:  { fontSize: 10, fontWeight: '600' },

  viewDetailBtn:   { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 4, paddingVertical: 10, borderRadius: 10, backgroundColor: `${COLORS.teal}10`, marginTop: 4 },
  viewDetailText:  { fontSize: 13, fontWeight: '600', color: COLORS.teal },
});
