import { create } from 'zustand';
import * as SecureStore from 'expo-secure-store';

export interface User {
  id:                 string;
  name:               string;
  phone:              string;
  email?:             string;
  role:               'user' | 'admin';
  preferences:        Record<string, any>;
  emergencyContact?:  string;
  savedRoutes?:       string[];
}

interface AuthStore {
  user:         User | null;
  token:        string | null;
  isLoading:    boolean;
  pendingPhone: string;

  initAuth:   () => Promise<void>;
  setAuth:    (token: string, user: User) => Promise<void>;
  setUser:    (user: User) => void;
  setPending: (phone: string) => void;
  logout:     () => Promise<void>;
  isAdmin:    () => boolean;
  updateEmergencyContact: (phone: string) => Promise<void>;
}

export const useAuthStore = create<AuthStore>((set, get) => ({
  user:         null,
  token:        null,
  isLoading:    true,
  pendingPhone: '',

  initAuth: async () => {
    try {
      const token   = await SecureStore.getItemAsync('transiq_token');
      const userStr = await SecureStore.getItemAsync('transiq_user');
      if (token && userStr) {
        set({ token, user: JSON.parse(userStr) });
      }
    } catch {
      await SecureStore.deleteItemAsync('transiq_token').catch(() => {});
      await SecureStore.deleteItemAsync('transiq_user').catch(() => {});
    } finally {
      set({ isLoading: false });
    }
  },

  setAuth: async (token, user) => {
    await SecureStore.setItemAsync('transiq_token', token);
    await SecureStore.setItemAsync('transiq_user', JSON.stringify(user));
    set({ token, user });
  },

  setUser: (user) => {
    SecureStore.setItemAsync('transiq_user', JSON.stringify(user)).catch(() => {});
    set({ user });
  },

  setPending: (phone) => set({ pendingPhone: phone }),

  logout: async () => {
    await SecureStore.deleteItemAsync('transiq_token').catch(() => {});
    await SecureStore.deleteItemAsync('transiq_user').catch(() => {});
    set({ user: null, token: null });
  },

  isAdmin: () => get().user?.role === 'admin',

  updateEmergencyContact: async (phone) => {
    const user = get().user;
    if (!user) return;
    const updated = { ...user, emergencyContact: phone };
    await SecureStore.setItemAsync('transiq_user', JSON.stringify(updated));
    set({ user: updated });
  },
}));
