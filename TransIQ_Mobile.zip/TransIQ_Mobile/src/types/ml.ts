// ── TransIQ ML Model Type Contracts ───────────────────────────────────────
// These types match the Lambda function input/output schemas defined in the
// project scope. Backend enriches the request before forwarding to Lambda.
// Use X-Mock: true header to get synthetic responses during development.

// ── Shared Request (sent from frontend → Spring Boot → Lambda) ─────────────
export interface MLPredictRequest {
  origin:       string;
  destination:  string;
  departTime:   string;       // ISO 8601
  budgetJmd?:   number;
  routeIds?:    string[];     // Added by Spring Boot from PostgreSQL
  trafficLevel?: number;      // 0–10, added by Spring Boot from Google Maps
  weatherCode?:  string;      // Added by Spring Boot from Met Service
  dayOfWeek?:   number;       // 0–6, derived by Spring Boot
  timeOfDay?:   'morning' | 'midday' | 'evening' | 'night'; // derived
}

// ── Model 1 — ETA Prediction ───────────────────────────────────────────────
export interface ETAPrediction {
  etaMinutes:  number;
  confidence:  number;        // 0–1
}

// ── Model 2 — Fare Prediction ──────────────────────────────────────────────
export interface FarePrediction {
  fareJmd:     number;
  confidence:  number;
}

// ── Model 3 — Traffic Congestion Level ────────────────────────────────────
export interface TrafficPrediction {
  congestionScore: number;    // 0–10
  label:           'clear' | 'moderate' | 'heavy';
}

// ── Model 4 — Best Departure Time ─────────────────────────────────────────
export interface DeparturePrediction {
  bestDepart:     string;     // ISO 8601
  windowMinutes:  number;
}

// ── Model 5 — Route Reliability Score ─────────────────────────────────────
export interface ReliabilityPrediction {
  reliabilityScore: number;   // 0–100
  grade:            'A' | 'B' | 'C' | 'D';
}

// ── Model 6 — Safety Score ─────────────────────────────────────────────────
export interface SafetyPrediction {
  safetyScore: number;        // 0–100
  riskLevel:   'low' | 'moderate' | 'high';
}

// ── Full ML Prediction Response (all 6 models combined) ────────────────────
export interface MLPredictResponse {
  eta:         ETAPrediction;
  fare:        FarePrediction;
  traffic:     TrafficPrediction;
  departure:   DeparturePrediction;
  reliability: ReliabilityPrediction;
  safety:      SafetyPrediction;
  planType:    'fastest' | 'cheapest' | 'balanced';
  isMock:      boolean;       // true when X-Mock header was used
}

// ── Plan Card (what gets displayed in the Route Results screen) ─────────────
export interface PlanCard {
  id:          string;
  planType:    'fastest' | 'cheapest' | 'balanced';
  label:       string;
  etaMinutes:  number;
  fareJmd:     number;
  transfers:   number;
  legs:        JourneyLeg[];
  ml:          MLPredictResponse;
  safetyRating: 'low' | 'moderate' | 'high';
}

// ── Journey Leg ────────────────────────────────────────────────────────────
export interface JourneyLeg {
  stepNumber:    number;
  type:          'walk' | 'bus' | 'taxi' | 'express' | 'juta' | 'uber';
  instruction:   string;
  fromStop:      string;
  toStop:        string;
  routeNumber:   string;
  operator:      string;
  fareJmd:       number;
  durationMins:  number;
  walkingMins?:  number;
  congestion?:   'clear' | 'moderate' | 'heavy';
}

// ── ML Mock Responses (used when X-Mock: true) ─────────────────────────────
export const ML_MOCK_RESPONSE: Omit<MLPredictResponse, 'planType'> = {
  eta:         { etaMinutes: 30,  confidence: 0.87 },
  fare:        { fareJmd: 200,    confidence: 0.91 },
  traffic:     { congestionScore: 4, label: 'moderate' },
  departure:   { bestDepart: new Date(Date.now() + 10 * 60000).toISOString(), windowMinutes: 15 },
  reliability: { reliabilityScore: 75, grade: 'B' },
  safety:      { safetyScore: 80,   riskLevel: 'low' },
  isMock:      true,
};
