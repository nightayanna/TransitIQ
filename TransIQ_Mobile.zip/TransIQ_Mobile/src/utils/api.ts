// ── TransIQ API Client ─────────────────────────────────────────────────────
import axios from 'axios';
import * as SecureStore from 'expo-secure-store';

const API_URL = process.env.EXPO_PUBLIC_API_URL || 'http://localhost:8080';

export const api = axios.create({
  baseURL: `${API_URL}/api`,
  timeout: 15000,
  headers: { 'Content-Type': 'application/json' },
});

// Attach JWT to every request
api.interceptors.request.use(async (config) => {
  try {
    const token = await SecureStore.getItemAsync('transiq_token');
    if (token) config.headers.Authorization = `Bearer ${token}`;
    // ML mock flag — set to 'true' until Lambda functions are live
    if (process.env.EXPO_PUBLIC_ML_MOCK === 'true') {
      config.headers['X-Mock'] = 'true';
    }
  } catch {}
  return config;
});

api.interceptors.response.use(
  (res) => res,
  async (err) => {
    if (err.response?.status === 401) {
      await SecureStore.deleteItemAsync('transiq_token');
    }
    return Promise.reject(err);
  }
);

// ── Auth ──────────────────────────────────────────────────────────────────
export const authApi = {
  register:  (phone: string, name: string) =>
    api.post('/auth/register', { phone, name }),
  verifyOtp: (phone: string, otp: string) =>
    api.post('/auth/verify-otp', { phone, otp }),
  me:        () => api.get('/auth/me'),
  logout:    (refreshToken: string) =>
    api.post('/auth/logout', { refreshToken }),
  updateProfile: (data: { name?: string; email?: string }) =>
    api.patch('/auth/profile', data),
};

// ── Journey / Route Planning ───────────────────────────────────────────────
export const routeApi = {
  // POST /api/routes — returns 3 ML-powered plans (fastest, cheapest, balanced)
  plan: (params: {
    origin: string;
    destination: string;
    departTime: string;
    budgetJmd?: number;
    preference?: 'fastest' | 'cheapest' | 'balanced';
  }) => api.post('/routes', params),

  history:  ()           => api.get('/routes/history'),
  get:      (id: string) => api.get(`/routes/${id}`),
  complete: (id: string) => api.patch(`/routes/${id}/complete`),
  save:     (id: string) => api.post(`/routes/${id}/save`),
  saved:    ()           => api.get('/routes/saved'),
};

// ── ML Predictions ─────────────────────────────────────────────────────────
// Single gateway endpoint — Spring Boot proxies to the correct Lambda function.
// Set X-Mock: true (via EXPO_PUBLIC_ML_MOCK=true) to return synthetic data
// until Ayanna's Lambda functions are deployed on hackathon day.
export const mlApi = {
  predict: (params: {
    origin: string;
    destination: string;
    departTime: string;
    budgetJmd?: number;
    routeIds?: string[];
  }) => api.post('/predict', params),
};

// ── Stops ──────────────────────────────────────────────────────────────────
export const stopsApi = {
  nearby: (lat: number, lng: number, radius = 800) =>
    api.get('/stops/nearby', { params: { lat, lng, radius } }),
  search: (q: string) =>
    api.get('/stops/search', { params: { q } }),
  all:    (parish?: string) =>
    api.get('/stops', { params: { parish } }),
};

// ── Fares ──────────────────────────────────────────────────────────────────
export const fareApi = {
  lookup:   (from: string, to: string) =>
    api.get('/fares/lookup', { params: { from, to } }),
  all:      (operator?: string) =>
    api.get('/fares', { params: { operator } }),
  // Uber live fare estimate via backend proxy (protects API key)
  uberEstimate: (originLat: number, originLng: number, destLat: number, destLng: number) =>
    api.post('/fares/uber-estimate', { originLat, originLng, destLat, destLng }),
};

// ── Safety ─────────────────────────────────────────────────────────────────
export const safetyApi = {
  zones:   () => api.get('/safety/zones'),
  check:   (lat: number, lng: number) =>
    api.get('/safety/check', { params: { lat, lng } }),
  // SOS — sends GPS coordinates to emergency contact
  sos: (params: {
    lat: number;
    lng: number;
    contactPhone: string;
    journeyId?: string;
  }) => api.post('/safety/sos', params),
  // Off-route check — called by GPS monitor during active journey
  offRouteCheck: (params: {
    journeyId: string;
    currentLat: number;
    currentLng: number;
  }) => api.post('/safety/off-route', params),
};

// ── Traffic (Kafka-backed) ──────────────────────────────────────────────────
export const trafficApi = {
  current: (routeIds: string[]) =>
    api.get('/traffic', { params: { routeIds: routeIds.join(',') } }),
};

// ── Snowflake Analytics ────────────────────────────────────────────────────
export const analyticsApi = {
  impact:        () => api.get('/analytics/impact'),
  routeTrends:   () => api.get('/analytics/routes'),
  commuterStats: () => api.get('/analytics/commuters'),
};

// ── Admin ──────────────────────────────────────────────────────────────────
export const adminApi = {
  dashboard:   () => api.get('/admin/dashboard'),
  users:       (page = 1) => api.get('/admin/users', { params: { page } }),
  feedback:    (status?: string) => api.get('/admin/feedback', { params: { status } }),
  triggerScrape: (source?: string) => api.post('/admin/scrape', null, { params: { source } }),
  mlStatus:    () => api.get('/admin/ml-status'),
};
