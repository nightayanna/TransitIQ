// ── TransIQ Design Tokens ──────────────────────────────────────────────────

export const COLORS = {
  // Brand
  navy:       '#0A2342',
  navyLight:  '#1A3A5C',
  teal:       '#0D9488',
  gold:       '#F59E0B',
  white:      '#FFFFFF',

  // Transport type colours
  bus:        '#0D9488',   // JUTC buses
  taxi:       '#F59E0B',   // Route taxis
  express:    '#6366F1',   // Knutsford / intercity
  juta:       '#10B981',   // JUTA tourism routes
  uber:       '#1C1C1C',   // Uber

  // Semantic
  fastest:    '#0D9488',
  cheapest:   '#10B981',
  balanced:   '#6366F1',

  safe:       '#10B981',
  caution:    '#F59E0B',
  danger:     '#EF4444',
  sos:        '#DC2626',

  // ML confidence colours
  mlHigh:     '#10B981',
  mlMed:      '#F59E0B',
  mlLow:      '#EF4444',

  // UI
  background: '#060F1E',
  surface:    '#0D1B2E',
  surfaceAlt: '#112240',
  border:     '#1E3A5F',
  muted:      '#64748B',
  text:       '#F1F5F9',
  textSec:    '#94A3B8',
};

export const SPACING = {
  xs:  4,
  sm:  8,
  md:  16,
  lg:  24,
  xl:  32,
  xxl: 48,
};

export const RADIUS = {
  sm:   8,
  md:   12,
  lg:   16,
  xl:   20,
  xxl:  24,
  full: 999,
};

export const SHADOW = {
  sm: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
  md: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
    elevation: 6,
  },
  lg: {
    shadowColor: '#0D9488',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.3,
    shadowRadius: 16,
    elevation: 10,
  },
};
