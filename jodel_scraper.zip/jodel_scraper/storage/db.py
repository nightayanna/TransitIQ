"""
storage/db.py — Database layer for TransIQ scraper
Supports SQLite (local/dev) and PostgreSQL (production).
Switch via DB_MODE in config.py or DB_MODE env var.
"""

import sqlite3
import json
import os
import sys
import logging
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from config import DB_MODE, SQLITE_DB_PATH, POSTGRES_URL

logger = logging.getLogger("transiq.db")


def get_connection():
    """Return a DB connection based on DB_MODE."""
    if DB_MODE == "postgres":
        try:
            import psycopg2
            return psycopg2.connect(POSTGRES_URL)
        except ImportError:
            logger.warning("psycopg2 not installed — falling back to SQLite")
    # Default: SQLite
    os.makedirs(os.path.dirname(SQLITE_DB_PATH), exist_ok=True)
    conn = sqlite3.connect(SQLITE_DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Create all tables if they don't exist (SQLite version)."""
    conn = get_connection()
    cur = conn.cursor()

    cur.executescript("""
        CREATE TABLE IF NOT EXISTS routes (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            route_id    TEXT UNIQUE NOT NULL,
            name        TEXT NOT NULL,
            type        TEXT NOT NULL,   -- taxi | bus | express | juta | uber
            origin      TEXT,
            destination TEXT,
            hubs        TEXT,            -- JSON array of hub names
            is_active   INTEGER DEFAULT 1,
            scraped_at  TEXT,
            created_at  TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS hubs (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            name        TEXT NOT NULL,
            area        TEXT,
            parish      TEXT,
            lat         REAL,
            lng         REAL,
            hub_type    TEXT,            -- terminal | stop | landmark
            created_at  TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS route_stops (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            route_id    TEXT NOT NULL,
            hub_name    TEXT NOT NULL,
            stop_order  INTEGER,
            FOREIGN KEY (route_id) REFERENCES routes(route_id)
        );

        CREATE TABLE IF NOT EXISTS fares (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            route_id    TEXT NOT NULL,
            fare_jmd    REAL NOT NULL,
            fare_usd    REAL,
            distance_km REAL,
            duration_min INTEGER,
            valid_from  TEXT,
            scraped_at  TEXT,
            FOREIGN KEY (route_id) REFERENCES routes(route_id)
        );

        CREATE TABLE IF NOT EXISTS traffic_events (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            event_type  TEXT,            -- congestion | incident | roadwork
            road        TEXT,
            area        TEXT,
            severity    TEXT,            -- low | medium | high | critical
            lat         REAL,
            lng         REAL,
            description TEXT,
            source      TEXT,
            expires_at  TEXT,
            created_at  TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS weather_alerts (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            alert_type  TEXT,            -- rain | flood | hurricane | clear
            severity    TEXT,
            parish      TEXT,
            description TEXT,
            valid_until TEXT,
            scraped_at  TEXT,
            created_at  TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS ml_predictions (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            route_id        TEXT,
            origin          TEXT,
            destination     TEXT,
            departure_time  TEXT,
            eta_minutes     REAL,
            fare_jmd        REAL,
            congestion_level TEXT,
            best_departure  TEXT,
            reliability_score REAL,
            safety_score    REAL,
            model_version   TEXT,
            created_at      TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS scrape_log (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            source      TEXT NOT NULL,
            status      TEXT NOT NULL,   -- success | failed | partial
            rows_upserted INTEGER DEFAULT 0,
            error_msg   TEXT,
            duration_ms INTEGER,
            scraped_at  TEXT DEFAULT (datetime('now'))
        );
    """)

    conn.commit()
    conn.close()
    logger.info("Database initialised successfully")


def upsert_route(route: dict):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO routes (route_id, name, type, origin, destination, hubs, scraped_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(route_id) DO UPDATE SET
            name=excluded.name, type=excluded.type,
            origin=excluded.origin, destination=excluded.destination,
            hubs=excluded.hubs, scraped_at=excluded.scraped_at, is_active=1
    """, (
        route["route_id"], route["name"], route["type"],
        route.get("origin"), route.get("destination"),
        json.dumps(route.get("hubs", [])),
        datetime.utcnow().isoformat()
    ))
    conn.commit()
    conn.close()


def upsert_fare(fare: dict):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO fares (route_id, fare_jmd, fare_usd, distance_km, duration_min, scraped_at)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (
        fare["route_id"], fare["fare_jmd"], fare.get("fare_usd"),
        fare.get("distance_km"), fare.get("duration_min"),
        datetime.utcnow().isoformat()
    ))
    conn.commit()
    conn.close()


def insert_traffic_event(event: dict):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO traffic_events
        (event_type, road, area, severity, lat, lng, description, source, expires_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        event.get("event_type", "congestion"),
        event.get("road"), event.get("area"),
        event.get("severity", "medium"),
        event.get("lat"), event.get("lng"),
        event.get("description"), event.get("source", "google_maps"),
        event.get("expires_at")
    ))
    conn.commit()
    conn.close()


def insert_weather_alert(alert: dict):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO weather_alerts (alert_type, severity, parish, description, valid_until, scraped_at)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (
        alert.get("alert_type", "clear"),
        alert.get("severity", "low"),
        alert.get("parish"), alert.get("description"),
        alert.get("valid_until"),
        datetime.utcnow().isoformat()
    ))
    conn.commit()
    conn.close()


def insert_ml_prediction(pred: dict):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO ml_predictions
        (route_id, origin, destination, departure_time, eta_minutes, fare_jmd,
         congestion_level, best_departure, reliability_score, safety_score, model_version)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        pred.get("route_id"), pred.get("origin"), pred.get("destination"),
        pred.get("departure_time"), pred.get("eta_minutes"), pred.get("fare_jmd"),
        pred.get("congestion_level"), pred.get("best_departure"),
        pred.get("reliability_score"), pred.get("safety_score"),
        pred.get("model_version", "ayanna-v1"),
    ))
    conn.commit()
    conn.close()


def get_latest_ml_prediction(origin: str, destination: str) -> dict | None:
    """Return the most recent ML prediction for a given origin→destination pair."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        SELECT * FROM ml_predictions
        WHERE LOWER(origin)=LOWER(?) AND LOWER(destination)=LOWER(?)
        ORDER BY created_at DESC LIMIT 1
    """, (origin, destination))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def get_all_ml_predictions(limit: int = 200) -> list[dict]:
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM ml_predictions ORDER BY created_at DESC LIMIT ?", (limit,))
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows


def log_scrape(source: str, status: str, rows: int = 0, error: str = None, duration_ms: int = 0):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO scrape_log (source, status, rows_upserted, error_msg, duration_ms)
        VALUES (?, ?, ?, ?, ?)
    """, (source, status, rows, error, duration_ms))
    conn.commit()
    conn.close()


def get_all_routes(route_type: str = None):
    conn = get_connection()
    cur = conn.cursor()
    if route_type:
        cur.execute("SELECT * FROM routes WHERE is_active=1 AND type=?", (route_type,))
    else:
        cur.execute("SELECT * FROM routes WHERE is_active=1")
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    for r in rows:
        r["hubs"] = json.loads(r.get("hubs") or "[]")
    return rows


def get_fares(route_id: str = None):
    conn = get_connection()
    cur = conn.cursor()
    if route_id:
        cur.execute(
            "SELECT * FROM fares WHERE route_id=? ORDER BY scraped_at DESC", (route_id,)
        )
    else:
        cur.execute("SELECT * FROM fares ORDER BY scraped_at DESC LIMIT 500")
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows


def get_traffic_events(active_only: bool = True):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "SELECT * FROM traffic_events ORDER BY created_at DESC LIMIT 100"
    )
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows


def get_weather_alerts():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM weather_alerts ORDER BY created_at DESC LIMIT 20")
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows


def get_scrape_status():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        SELECT source, status, rows_upserted, scraped_at
        FROM scrape_log
        WHERE id IN (
            SELECT MAX(id) FROM scrape_log GROUP BY source
        )
        ORDER BY scraped_at DESC
    """)
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows


if __name__ == "__main__":
    logging.basicConfig(level="INFO")
    init_db()
    print("✅ DB initialised at:", SQLITE_DB_PATH)
