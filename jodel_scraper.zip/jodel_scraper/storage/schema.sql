-- TransIQ PostgreSQL Schema
-- Run this on AWS RDS before deploying the scraper
-- Compatible with psycopg2 and Spring Boot JPA

CREATE TABLE IF NOT EXISTS routes (
    id          SERIAL PRIMARY KEY,
    route_id    VARCHAR(64) UNIQUE NOT NULL,
    name        TEXT NOT NULL,
    type        VARCHAR(20) NOT NULL CHECK (type IN ('taxi','bus','express','juta','uber')),
    origin      TEXT,
    destination TEXT,
    hubs        JSONB DEFAULT '[]',
    is_active   BOOLEAN DEFAULT TRUE,
    scraped_at  TIMESTAMP,
    created_at  TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS hubs (
    id          SERIAL PRIMARY KEY,
    name        TEXT NOT NULL,
    area        TEXT,
    parish      VARCHAR(50),
    lat         DOUBLE PRECISION,
    lng         DOUBLE PRECISION,
    hub_type    VARCHAR(20) CHECK (hub_type IN ('terminal','stop','landmark')),
    created_at  TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS route_stops (
    id          SERIAL PRIMARY KEY,
    route_id    VARCHAR(64) NOT NULL REFERENCES routes(route_id),
    hub_name    TEXT NOT NULL,
    stop_order  INTEGER
);

CREATE TABLE IF NOT EXISTS fares (
    id           SERIAL PRIMARY KEY,
    route_id     VARCHAR(64) NOT NULL REFERENCES routes(route_id),
    fare_jmd     NUMERIC(10,2) NOT NULL,
    fare_usd     NUMERIC(10,2),
    distance_km  NUMERIC(8,2),
    duration_min INTEGER,
    valid_from   DATE,
    scraped_at   TIMESTAMP
);

CREATE TABLE IF NOT EXISTS traffic_events (
    id          SERIAL PRIMARY KEY,
    event_type  VARCHAR(30),
    road        TEXT,
    area        TEXT,
    severity    VARCHAR(20) CHECK (severity IN ('low','medium','high','critical')),
    lat         DOUBLE PRECISION,
    lng         DOUBLE PRECISION,
    description TEXT,
    source      VARCHAR(30),
    expires_at  TIMESTAMP,
    created_at  TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS weather_alerts (
    id          SERIAL PRIMARY KEY,
    alert_type  VARCHAR(30),
    severity    VARCHAR(20),
    parish      VARCHAR(50),
    description TEXT,
    valid_until TIMESTAMP,
    scraped_at  TIMESTAMP,
    created_at  TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS ml_predictions (
    id                SERIAL PRIMARY KEY,
    route_id          VARCHAR(64),
    origin            TEXT,
    destination       TEXT,
    departure_time    TIMESTAMP,
    eta_minutes       NUMERIC(8,2),
    fare_jmd          NUMERIC(10,2),
    congestion_level  VARCHAR(20),
    best_departure    TEXT,
    reliability_score NUMERIC(4,2),
    safety_score      NUMERIC(4,2),
    model_version     VARCHAR(20),
    created_at        TIMESTAMP DEFAULT NOW()
);

-- Users table (for Spring Boot auth integration)
CREATE TABLE IF NOT EXISTS users (
    id              SERIAL PRIMARY KEY,
    email           VARCHAR(255) UNIQUE NOT NULL,
    password_hash   TEXT NOT NULL,
    full_name       TEXT,
    phone           VARCHAR(20),
    emergency_contact_phone VARCHAR(20),
    emergency_contact_name  TEXT,
    created_at      TIMESTAMP DEFAULT NOW(),
    last_login      TIMESTAMP
);

-- Trip history
CREATE TABLE IF NOT EXISTS trips (
    id              SERIAL PRIMARY KEY,
    user_id         INTEGER REFERENCES users(id),
    origin          TEXT NOT NULL,
    destination     TEXT NOT NULL,
    plan_type       VARCHAR(20) CHECK (plan_type IN ('fastest','cheapest','balanced')),
    route_ids       JSONB,
    eta_minutes     INTEGER,
    fare_jmd        NUMERIC(10,2),
    departed_at     TIMESTAMP,
    arrived_at      TIMESTAMP,
    status          VARCHAR(20) DEFAULT 'planned',
    created_at      TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS scrape_log (
    id              SERIAL PRIMARY KEY,
    source          VARCHAR(50) NOT NULL,
    status          VARCHAR(20) NOT NULL,
    rows_upserted   INTEGER DEFAULT 0,
    error_msg       TEXT,
    duration_ms     INTEGER,
    scraped_at      TIMESTAMP DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_routes_type     ON routes(type);
CREATE INDEX IF NOT EXISTS idx_routes_active   ON routes(is_active);
CREATE INDEX IF NOT EXISTS idx_fares_route     ON fares(route_id);
CREATE INDEX IF NOT EXISTS idx_traffic_created ON traffic_events(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_trips_user      ON trips(user_id);
CREATE INDEX IF NOT EXISTS idx_trips_created   ON trips(created_at DESC);
